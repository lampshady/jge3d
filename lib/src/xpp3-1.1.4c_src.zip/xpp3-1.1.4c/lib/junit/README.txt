Latest JUnit jar downloaded from http://www.junit.org/
