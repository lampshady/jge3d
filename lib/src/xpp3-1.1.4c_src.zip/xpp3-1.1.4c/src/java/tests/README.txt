This is copy of src/java/tests directory from xmlpull-api-v1 CVS
for more details see: http://www.xmlpull.org
