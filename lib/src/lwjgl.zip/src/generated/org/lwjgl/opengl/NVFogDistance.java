/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class NVFogDistance {
	public static final int GL_FOG_DISTANCE_MODE_NV = 0x855a;
	public static final int GL_EYE_RADIAL_NV = 0x855b;
	public static final int GL_EYE_PLANE_ABSOLUTE_NV = 0x855c;

	private NVFogDistance() {
	}

}
