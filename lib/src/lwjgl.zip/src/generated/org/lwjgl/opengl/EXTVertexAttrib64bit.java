/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class EXTVertexAttrib64bit {
	/**
	 * Returned in the &lt;type&gt; parameter of GetActiveAttrib: 
	 */
	public static final int GL_DOUBLE_VEC2_EXT = 0x8ffc;
	public static final int GL_DOUBLE_VEC3_EXT = 0x8ffd;
	public static final int GL_DOUBLE_VEC4_EXT = 0x8ffe;
	public static final int GL_DOUBLE_MAT2_EXT = 0x8f46;
	public static final int GL_DOUBLE_MAT3_EXT = 0x8f47;
	public static final int GL_DOUBLE_MAT4_EXT = 0x8f48;
	public static final int GL_DOUBLE_MAT2x3_EXT = 0x8f49;
	public static final int GL_DOUBLE_MAT2x4_EXT = 0x8f4a;
	public static final int GL_DOUBLE_MAT3x2_EXT = 0x8f4b;
	public static final int GL_DOUBLE_MAT3x4_EXT = 0x8f4c;
	public static final int GL_DOUBLE_MAT4x2_EXT = 0x8f4d;
	public static final int GL_DOUBLE_MAT4x3_EXT = 0x8f4e;

	private EXTVertexAttrib64bit() {
	}


	public static void glVertexAttribL1dEXT(int index, double x) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.EXT_vertex_attrib_64bit_glVertexAttribL1dEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglVertexAttribL1dEXT(index, x, function_pointer);
	}
	private static native void nglVertexAttribL1dEXT(int index, double x, long function_pointer);

	public static void glVertexAttribL2dEXT(int index, double x, double y) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.EXT_vertex_attrib_64bit_glVertexAttribL2dEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglVertexAttribL2dEXT(index, x, y, function_pointer);
	}
	private static native void nglVertexAttribL2dEXT(int index, double x, double y, long function_pointer);

	public static void glVertexAttribL3dEXT(int index, double x, double y, double z) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.EXT_vertex_attrib_64bit_glVertexAttribL3dEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglVertexAttribL3dEXT(index, x, y, z, function_pointer);
	}
	private static native void nglVertexAttribL3dEXT(int index, double x, double y, double z, long function_pointer);

	public static void glVertexAttribL4dEXT(int index, double x, double y, double z, double w) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.EXT_vertex_attrib_64bit_glVertexAttribL4dEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglVertexAttribL4dEXT(index, x, y, z, w, function_pointer);
	}
	private static native void nglVertexAttribL4dEXT(int index, double x, double y, double z, double w, long function_pointer);

	public static void glVertexAttribL1EXT(int index, DoubleBuffer v) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.EXT_vertex_attrib_64bit_glVertexAttribL1dvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(v, 1);
		nglVertexAttribL1dvEXT(index, v, v.position(), function_pointer);
	}
	private static native void nglVertexAttribL1dvEXT(int index, DoubleBuffer v, int v_position, long function_pointer);

	public static void glVertexAttribL2EXT(int index, DoubleBuffer v) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.EXT_vertex_attrib_64bit_glVertexAttribL2dvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(v, 2);
		nglVertexAttribL2dvEXT(index, v, v.position(), function_pointer);
	}
	private static native void nglVertexAttribL2dvEXT(int index, DoubleBuffer v, int v_position, long function_pointer);

	public static void glVertexAttribL3EXT(int index, DoubleBuffer v) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.EXT_vertex_attrib_64bit_glVertexAttribL3dvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(v, 3);
		nglVertexAttribL3dvEXT(index, v, v.position(), function_pointer);
	}
	private static native void nglVertexAttribL3dvEXT(int index, DoubleBuffer v, int v_position, long function_pointer);

	public static void glVertexAttribL4EXT(int index, DoubleBuffer v) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.EXT_vertex_attrib_64bit_glVertexAttribL4dvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(v, 4);
		nglVertexAttribL4dvEXT(index, v, v.position(), function_pointer);
	}
	private static native void nglVertexAttribL4dvEXT(int index, DoubleBuffer v, int v_position, long function_pointer);

	public static void glVertexAttribLPointerEXT(int index, int size, int stride, DoubleBuffer pointer) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.EXT_vertex_attrib_64bit_glVertexAttribLPointerEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureArrayVBOdisabled(caps);
		BufferChecks.checkDirect(pointer);
		GLChecks.getReferences(caps).glVertexAttribPointer_buffer[index] = pointer;
		nglVertexAttribLPointerEXT(index, size, GL11.GL_DOUBLE, stride, pointer, pointer.position() << 3, function_pointer);
	}
	private static native void nglVertexAttribLPointerEXT(int index, int size, int type, int stride, Buffer pointer, int pointer_position, long function_pointer);
	public static void glVertexAttribLPointerEXT(int index, int size, int stride, long pointer_buffer_offset) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.EXT_vertex_attrib_64bit_glVertexAttribLPointerEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureArrayVBOenabled(caps);
		nglVertexAttribLPointerEXTBO(index, size, GL11.GL_DOUBLE, stride, pointer_buffer_offset, function_pointer);
	}
	private static native void nglVertexAttribLPointerEXTBO(int index, int size, int type, int stride, long pointer_buffer_offset, long function_pointer);

	public static void glGetVertexAttribLEXT(int index, int pname, DoubleBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.EXT_vertex_attrib_64bit_glGetVertexAttribLdvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 4);
		nglGetVertexAttribLdvEXT(index, pname, params, params.position(), function_pointer);
	}
	private static native void nglGetVertexAttribLdvEXT(int index, int pname, DoubleBuffer params, int params_position, long function_pointer);

	public static void glVertexArrayVertexAttribLOffsetEXT(int vaobj, int buffer, int index, int size, int type, int stride, long offset) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.EXT_vertex_attrib_64bit_glVertexArrayVertexAttribLOffsetEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglVertexArrayVertexAttribLOffsetEXT(vaobj, buffer, index, size, type, stride, offset, function_pointer);
	}
	private static native void nglVertexArrayVertexAttribLOffsetEXT(int vaobj, int buffer, int index, int size, int type, int stride, long offset, long function_pointer);
}
