/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class NVExplicitMultisample {
	/**
	 * Accepted by the &lt;pname&gt; parameter of GetMultisamplefvNV: 
	 */
	public static final int GL_SAMPLE_POSITION_NV = 0x8e50;
	/**
	 *  Accepted by the &lt;cap&gt; parameter of Enable, Disable, and IsEnabled, and by
	 *  the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv, GetFloatv, and
	 *  GetDoublev:
	 */
	public static final int GL_SAMPLE_MASK_NV = 0x8e51;
	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanIndexedvEXT and
	 *  GetIntegerIndexedvEXT:
	 */
	public static final int GL_SAMPLE_MASK_VALUE_NV = 0x8e52;
	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetDoublev, GetIntegerv,
	 *  and GetFloatv:
	 */
	public static final int GL_TEXTURE_BINDING_RENDERBUFFER_NV = 0x8e53;
	public static final int GL_TEXTURE_RENDERBUFFER_DATA_STORE_BINDING_NV = 0x8e54;
	public static final int GL_MAX_SAMPLE_MASK_WORDS_NV = 0x8e59;
	/**
	 * Accepted by the &lt;target&gt; parameter of BindTexture, and TexRenderbufferNV: 
	 */
	public static final int GL_TEXTURE_RENDERBUFFER_NV = 0x8e55;
	/**
	 * Returned by the &lt;type&gt; parameter of GetActiveUniform: 
	 */
	public static final int GL_SAMPLER_RENDERBUFFER_NV = 0x8e56;
	public static final int GL_INT_SAMPLER_RENDERBUFFER_NV = 0x8e57;
	public static final int GL_UNSIGNED_INT_SAMPLER_RENDERBUFFER_NV = 0x8e58;

	private NVExplicitMultisample() {
	}


	public static void glGetBooleanIndexedEXT(int pname, int index, ByteBuffer data) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_explicit_multisample_glGetBooleanIndexedvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(data, 16);
		nglGetBooleanIndexedvEXT(pname, index, data, data.position(), function_pointer);
	}
	private static native void nglGetBooleanIndexedvEXT(int pname, int index, ByteBuffer data, int data_position, long function_pointer);

	/** Overloads glGetBooleanIndexedvEXT */
	public static boolean glGetBooleanIndexedEXT(int pname, int index) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_explicit_multisample_glGetBooleanIndexedvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		ByteBuffer data = APIUtils.getBufferByte(1);
		nglGetBooleanIndexedvEXT(pname, index, data, data.position(), function_pointer);
		return data.get(0) == 1;
	}

	public static void glGetIntegerIndexedEXT(int pname, int index, IntBuffer data) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_explicit_multisample_glGetIntegerIndexedvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(data, 16);
		nglGetIntegerIndexedvEXT(pname, index, data, data.position(), function_pointer);
	}
	private static native void nglGetIntegerIndexedvEXT(int pname, int index, IntBuffer data, int data_position, long function_pointer);

	/** Overloads glGetIntegerIndexedvEXT */
	public static int glGetIntegerIndexedEXT(int pname, int index) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_explicit_multisample_glGetIntegerIndexedvEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer data = APIUtils.getBufferInt();
		nglGetIntegerIndexedvEXT(pname, index, data, data.position(), function_pointer);
		return data.get(0);
	}

	public static void glGetMultisampleNV(int pname, int index, FloatBuffer val) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_explicit_multisample_glGetMultisamplefvNV_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(val, 2);
		nglGetMultisamplefvNV(pname, index, val, val.position(), function_pointer);
	}
	private static native void nglGetMultisamplefvNV(int pname, int index, FloatBuffer val, int val_position, long function_pointer);

	public static void glSampleMaskIndexedNV(int index, int mask) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_explicit_multisample_glSampleMaskIndexedNV_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglSampleMaskIndexedNV(index, mask, function_pointer);
	}
	private static native void nglSampleMaskIndexedNV(int index, int mask, long function_pointer);

	public static void glTexRenderbufferNV(int target, int renderbuffer) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_explicit_multisample_glTexRenderbufferNV_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglTexRenderbufferNV(target, renderbuffer, function_pointer);
	}
	private static native void nglTexRenderbufferNV(int target, int renderbuffer, long function_pointer);
}
