/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class ARBSamplerObjects {
	/**
	 *  Accepted by the &lt;value&gt; parameter of the GetBooleanv, GetIntegerv,
	 *  GetInteger64v, GetFloatv and GetDoublev functions:
	 */
	public static final int GL_SAMPLER_BINDING = 0x8919;

	private ARBSamplerObjects() {
	}


	public static void glGenSamplers(IntBuffer samplers) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sampler_objects_glGenSamplers_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(samplers);
		nglGenSamplers((samplers.remaining()), samplers, samplers.position(), function_pointer);
	}
	private static native void nglGenSamplers(int count, IntBuffer samplers, int samplers_position, long function_pointer);

	/** Overloads glGenSamplers */
	public static int glGenSamplers() {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sampler_objects_glGenSamplers_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer samplers = APIUtils.getBufferInt();
		nglGenSamplers(1, samplers, samplers.position(), function_pointer);
		return samplers.get(0);
	}

	public static void glDeleteSamplers(IntBuffer samplers) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sampler_objects_glDeleteSamplers_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(samplers);
		nglDeleteSamplers((samplers.remaining()), samplers, samplers.position(), function_pointer);
	}
	private static native void nglDeleteSamplers(int count, IntBuffer samplers, int samplers_position, long function_pointer);

	/** Overloads glDeleteSamplers */
	public static void glDeleteSamplers(int sampler) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sampler_objects_glDeleteSamplers_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglDeleteSamplers(1, APIUtils.getBufferInt().put(0, sampler), 0, function_pointer);
	}

	public static boolean glIsSampler(int sampler) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sampler_objects_glIsSampler_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		boolean __result = nglIsSampler(sampler, function_pointer);
		return __result;
	}
	private static native boolean nglIsSampler(int sampler, long function_pointer);

	public static void glBindSampler(int unit, int sampler) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sampler_objects_glBindSampler_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglBindSampler(unit, sampler, function_pointer);
	}
	private static native void nglBindSampler(int unit, int sampler, long function_pointer);

	public static void glSamplerParameteri(int sampler, int pname, int param) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sampler_objects_glSamplerParameteri_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglSamplerParameteri(sampler, pname, param, function_pointer);
	}
	private static native void nglSamplerParameteri(int sampler, int pname, int param, long function_pointer);

	public static void glSamplerParameterf(int sampler, int pname, float param) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sampler_objects_glSamplerParameterf_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglSamplerParameterf(sampler, pname, param, function_pointer);
	}
	private static native void nglSamplerParameterf(int sampler, int pname, float param, long function_pointer);

	public static void glSamplerParameter(int sampler, int pname, IntBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sampler_objects_glSamplerParameteriv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 4);
		nglSamplerParameteriv(sampler, pname, params, params.position(), function_pointer);
	}
	private static native void nglSamplerParameteriv(int sampler, int pname, IntBuffer params, int params_position, long function_pointer);

	public static void glSamplerParameter(int sampler, int pname, FloatBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sampler_objects_glSamplerParameterfv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 4);
		nglSamplerParameterfv(sampler, pname, params, params.position(), function_pointer);
	}
	private static native void nglSamplerParameterfv(int sampler, int pname, FloatBuffer params, int params_position, long function_pointer);

	public static void glSamplerParameterI(int sampler, int pname, IntBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sampler_objects_glSamplerParameterIiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 4);
		nglSamplerParameterIiv(sampler, pname, params, params.position(), function_pointer);
	}
	private static native void nglSamplerParameterIiv(int sampler, int pname, IntBuffer params, int params_position, long function_pointer);

	public static void glSamplerParameterIu(int sampler, int pname, IntBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sampler_objects_glSamplerParameterIuiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 4);
		nglSamplerParameterIuiv(sampler, pname, params, params.position(), function_pointer);
	}
	private static native void nglSamplerParameterIuiv(int sampler, int pname, IntBuffer params, int params_position, long function_pointer);

	public static void glGetSamplerParameter(int sampler, int pname, IntBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sampler_objects_glGetSamplerParameteriv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 4);
		nglGetSamplerParameteriv(sampler, pname, params, params.position(), function_pointer);
	}
	private static native void nglGetSamplerParameteriv(int sampler, int pname, IntBuffer params, int params_position, long function_pointer);

	/** Overloads glGetSamplerParameteriv */
	public static int glGetSamplerParameteri(int sampler, int pname) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sampler_objects_glGetSamplerParameteriv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer params = APIUtils.getBufferInt();
		nglGetSamplerParameteriv(sampler, pname, params, params.position(), function_pointer);
		return params.get(0);
	}

	public static void glGetSamplerParameter(int sampler, int pname, FloatBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sampler_objects_glGetSamplerParameterfv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 4);
		nglGetSamplerParameterfv(sampler, pname, params, params.position(), function_pointer);
	}
	private static native void nglGetSamplerParameterfv(int sampler, int pname, FloatBuffer params, int params_position, long function_pointer);

	/** Overloads glGetSamplerParameterfv */
	public static float glGetSamplerParameterf(int sampler, int pname) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sampler_objects_glGetSamplerParameterfv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		FloatBuffer params = APIUtils.getBufferFloat();
		nglGetSamplerParameterfv(sampler, pname, params, params.position(), function_pointer);
		return params.get(0);
	}

	public static void glGetSamplerParameterI(int sampler, int pname, IntBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sampler_objects_glGetSamplerParameterIiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 4);
		nglGetSamplerParameterIiv(sampler, pname, params, params.position(), function_pointer);
	}
	private static native void nglGetSamplerParameterIiv(int sampler, int pname, IntBuffer params, int params_position, long function_pointer);

	/** Overloads glGetSamplerParameterIiv */
	public static int glGetSamplerParameterIi(int sampler, int pname) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sampler_objects_glGetSamplerParameterIiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer params = APIUtils.getBufferInt();
		nglGetSamplerParameterIiv(sampler, pname, params, params.position(), function_pointer);
		return params.get(0);
	}

	public static void glGetSamplerParameterIu(int sampler, int pname, IntBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sampler_objects_glGetSamplerParameterIuiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 4);
		nglGetSamplerParameterIuiv(sampler, pname, params, params.position(), function_pointer);
	}
	private static native void nglGetSamplerParameterIuiv(int sampler, int pname, IntBuffer params, int params_position, long function_pointer);

	/** Overloads glGetSamplerParameterIuiv */
	public static int glGetSamplerParameterIui(int sampler, int pname) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sampler_objects_glGetSamplerParameterIuiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer params = APIUtils.getBufferInt();
		nglGetSamplerParameterIuiv(sampler, pname, params, params.position(), function_pointer);
		return params.get(0);
	}
}
