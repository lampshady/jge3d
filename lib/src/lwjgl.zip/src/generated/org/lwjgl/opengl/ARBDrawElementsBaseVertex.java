/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class ARBDrawElementsBaseVertex {

	private ARBDrawElementsBaseVertex() {
	}


	public static void glDrawElementsBaseVertex(int mode, ByteBuffer indices, int basevertex) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_draw_elements_base_vertex_glDrawElementsBaseVertex_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureElementVBOdisabled(caps);
		BufferChecks.checkDirect(indices);
		nglDrawElementsBaseVertex(mode, (indices.remaining()), GL11.GL_UNSIGNED_BYTE, indices, indices.position(), basevertex, function_pointer);
	}
	public static void glDrawElementsBaseVertex(int mode, IntBuffer indices, int basevertex) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_draw_elements_base_vertex_glDrawElementsBaseVertex_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureElementVBOdisabled(caps);
		BufferChecks.checkDirect(indices);
		nglDrawElementsBaseVertex(mode, (indices.remaining()), GL11.GL_UNSIGNED_INT, indices, indices.position() << 2, basevertex, function_pointer);
	}
	public static void glDrawElementsBaseVertex(int mode, ShortBuffer indices, int basevertex) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_draw_elements_base_vertex_glDrawElementsBaseVertex_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureElementVBOdisabled(caps);
		BufferChecks.checkDirect(indices);
		nglDrawElementsBaseVertex(mode, (indices.remaining()), GL11.GL_UNSIGNED_SHORT, indices, indices.position() << 1, basevertex, function_pointer);
	}
	private static native void nglDrawElementsBaseVertex(int mode, int count, int type, Buffer indices, int indices_position, int basevertex, long function_pointer);
	public static void glDrawElementsBaseVertex(int mode, int count, int type, long indices_buffer_offset, int basevertex) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_draw_elements_base_vertex_glDrawElementsBaseVertex_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureElementVBOenabled(caps);
		nglDrawElementsBaseVertexBO(mode, count, type, indices_buffer_offset, basevertex, function_pointer);
	}
	private static native void nglDrawElementsBaseVertexBO(int mode, int count, int type, long indices_buffer_offset, int basevertex, long function_pointer);

	public static void glDrawRangeElementsBaseVertex(int mode, int start, int end, ByteBuffer indices, int basevertex) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_draw_elements_base_vertex_glDrawRangeElementsBaseVertex_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureElementVBOdisabled(caps);
		BufferChecks.checkDirect(indices);
		nglDrawRangeElementsBaseVertex(mode, start, end, (indices.remaining()), GL11.GL_UNSIGNED_BYTE, indices, indices.position(), basevertex, function_pointer);
	}
	public static void glDrawRangeElementsBaseVertex(int mode, int start, int end, IntBuffer indices, int basevertex) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_draw_elements_base_vertex_glDrawRangeElementsBaseVertex_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureElementVBOdisabled(caps);
		BufferChecks.checkDirect(indices);
		nglDrawRangeElementsBaseVertex(mode, start, end, (indices.remaining()), GL11.GL_UNSIGNED_INT, indices, indices.position() << 2, basevertex, function_pointer);
	}
	public static void glDrawRangeElementsBaseVertex(int mode, int start, int end, ShortBuffer indices, int basevertex) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_draw_elements_base_vertex_glDrawRangeElementsBaseVertex_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureElementVBOdisabled(caps);
		BufferChecks.checkDirect(indices);
		nglDrawRangeElementsBaseVertex(mode, start, end, (indices.remaining()), GL11.GL_UNSIGNED_SHORT, indices, indices.position() << 1, basevertex, function_pointer);
	}
	private static native void nglDrawRangeElementsBaseVertex(int mode, int start, int end, int count, int type, Buffer indices, int indices_position, int basevertex, long function_pointer);
	public static void glDrawRangeElementsBaseVertex(int mode, int start, int end, int count, int type, long indices_buffer_offset, int basevertex) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_draw_elements_base_vertex_glDrawRangeElementsBaseVertex_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureElementVBOenabled(caps);
		nglDrawRangeElementsBaseVertexBO(mode, start, end, count, type, indices_buffer_offset, basevertex, function_pointer);
	}
	private static native void nglDrawRangeElementsBaseVertexBO(int mode, int start, int end, int count, int type, long indices_buffer_offset, int basevertex, long function_pointer);

	public static void glDrawElementsInstancedBaseVertex(int mode, ByteBuffer indices, int primcount, int basevertex) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_draw_elements_base_vertex_glDrawElementsInstancedBaseVertex_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureElementVBOdisabled(caps);
		BufferChecks.checkDirect(indices);
		nglDrawElementsInstancedBaseVertex(mode, (indices.remaining()), GL11.GL_UNSIGNED_BYTE, indices, indices.position(), primcount, basevertex, function_pointer);
	}
	public static void glDrawElementsInstancedBaseVertex(int mode, IntBuffer indices, int primcount, int basevertex) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_draw_elements_base_vertex_glDrawElementsInstancedBaseVertex_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureElementVBOdisabled(caps);
		BufferChecks.checkDirect(indices);
		nglDrawElementsInstancedBaseVertex(mode, (indices.remaining()), GL11.GL_UNSIGNED_INT, indices, indices.position() << 2, primcount, basevertex, function_pointer);
	}
	public static void glDrawElementsInstancedBaseVertex(int mode, ShortBuffer indices, int primcount, int basevertex) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_draw_elements_base_vertex_glDrawElementsInstancedBaseVertex_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureElementVBOdisabled(caps);
		BufferChecks.checkDirect(indices);
		nglDrawElementsInstancedBaseVertex(mode, (indices.remaining()), GL11.GL_UNSIGNED_SHORT, indices, indices.position() << 1, primcount, basevertex, function_pointer);
	}
	private static native void nglDrawElementsInstancedBaseVertex(int mode, int count, int type, Buffer indices, int indices_position, int primcount, int basevertex, long function_pointer);
	public static void glDrawElementsInstancedBaseVertex(int mode, int count, int type, long indices_buffer_offset, int primcount, int basevertex) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_draw_elements_base_vertex_glDrawElementsInstancedBaseVertex_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureElementVBOenabled(caps);
		nglDrawElementsInstancedBaseVertexBO(mode, count, type, indices_buffer_offset, primcount, basevertex, function_pointer);
	}
	private static native void nglDrawElementsInstancedBaseVertexBO(int mode, int count, int type, long indices_buffer_offset, int primcount, int basevertex, long function_pointer);
}
