/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class HPOcclusionTest {
	/**
	 * Accepted by the &lt;cap&gt; parameter of Enable, Disable, and IsEnabled, by
	 * the &lt;pname&gt; of GetBooleanv, GetIntegerv, GetFloatv, and GetDoublev :
	 */
	public static final int GL_OCCLUSION_TEST_HP = 0x8165;
	/**
	 * Accepted by the &lt;pname&gt; of GetBooleanv, GetIntegerv, GetFloatv, and
	 * GetDoublev :
	 */
	public static final int GL_OCCLUSION_TEST_RESULT_HP = 0x8166;

	private HPOcclusionTest() {
	}

}
