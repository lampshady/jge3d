/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class ARBSync {
	/**
	 *Accepted as the &lt;pname&gt; parameter of GetInteger64v: 
	 */
	public static final int GL_MAX_SERVER_WAIT_TIMEOUT = 0x9111;
	/**
	 *Accepted as the &lt;pname&gt; parameter of GetSynciv: 
	 */
	public static final int GL_OBJECT_TYPE = 0x9112;
	public static final int GL_SYNC_CONDITION = 0x9113;
	public static final int GL_SYNC_STATUS = 0x9114;
	public static final int GL_SYNC_FLAGS = 0x9115;
	/**
	 *Returned in &lt;values&gt; for GetSynciv &lt;pname&gt; OBJECT_TYPE: 
	 */
	public static final int GL_SYNC_FENCE = 0x9116;
	/**
	 *Returned in &lt;values&gt; for GetSynciv &lt;pname&gt; SYNC_CONDITION: 
	 */
	public static final int GL_SYNC_GPU_COMMANDS_COMPLETE = 0x9117;
	/**
	 *Returned in &lt;values&gt; for GetSynciv &lt;pname&gt; SYNC_STATUS: 
	 */
	public static final int GL_UNSIGNALED = 0x9118;
	public static final int GL_SIGNALED = 0x9119;
	/**
	 *Accepted in the &lt;flags&gt; parameter of ClientWaitSync: 
	 */
	public static final int GL_SYNC_FLUSH_COMMANDS_BIT = 0x1;
	/**
	 *Accepted in the &lt;timeout&gt; parameter of WaitSync: 
	 */
	public static final long GL_TIMEOUT_IGNORED = 0xffffffffffffffffl;
	/**
	 *Returned by ClientWaitSync: 
	 */
	public static final int GL_ALREADY_SIGNALED = 0x911a;
	public static final int GL_TIMEOUT_EXPIRED = 0x911b;
	public static final int GL_CONDITION_SATISFIED = 0x911c;
	public static final int GL_WAIT_FAILED = 0x911d;

	private ARBSync() {
	}


	public static org.lwjgl.opengl.GLSync glFenceSync(int condition, int flags) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sync_glFenceSync_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		org.lwjgl.opengl.GLSync __result = new org.lwjgl.opengl.GLSync(nglFenceSync(condition, flags, function_pointer));
		return __result;
	}
	private static native long nglFenceSync(int condition, int flags, long function_pointer);

	public static boolean glIsSync(GLSync sync) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sync_glIsSync_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		boolean __result = nglIsSync(sync.getPointer(), function_pointer);
		return __result;
	}
	private static native boolean nglIsSync(long sync, long function_pointer);

	public static void glDeleteSync(GLSync sync) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sync_glDeleteSync_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglDeleteSync(sync.getPointer(), function_pointer);
	}
	private static native void nglDeleteSync(long sync, long function_pointer);

	public static int glClientWaitSync(GLSync sync, int flags, long timeout) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sync_glClientWaitSync_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		int __result = nglClientWaitSync(sync.getPointer(), flags, timeout, function_pointer);
		return __result;
	}
	private static native int nglClientWaitSync(long sync, int flags, long timeout, long function_pointer);

	public static void glWaitSync(GLSync sync, int flags, long timeout) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sync_glWaitSync_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglWaitSync(sync.getPointer(), flags, timeout, function_pointer);
	}
	private static native void nglWaitSync(long sync, int flags, long timeout, long function_pointer);

	public static void glGetInteger(int pname, LongBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sync_glGetInteger64v_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 1);
		nglGetInteger64v(pname, params, params.position(), function_pointer);
	}
	private static native void nglGetInteger64v(int pname, LongBuffer params, int params_position, long function_pointer);

	public static void glGetSync(GLSync sync, int pname, IntBuffer length, IntBuffer values) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_sync_glGetSynciv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		if (length != null)
			BufferChecks.checkBuffer(length, 1);
		BufferChecks.checkDirect(values);
		nglGetSynciv(sync.getPointer(), pname, (values.remaining()), length, length != null ? length.position() : 0, values, values.position(), function_pointer);
	}
	private static native void nglGetSynciv(long sync, int pname, int bufSize, IntBuffer length, int length_position, IntBuffer values, int values_position, long function_pointer);
}
