/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class ARBCopyBuffer {
	/**
	 * Accepted by the target parameters of BindBuffer, BufferData,
	 * BufferSubData, MapBuffer, UnmapBuffer, GetBufferSubData,
	 * GetBufferPointerv, MapBufferRange, FlushMappedBufferRange,
	 * GetBufferParameteriv, BindBufferRange, BindBufferBase,
	 * and CopyBufferSubData:
	 */
	public static final int GL_COPY_READ_BUFFER = 0x8f36;
	public static final int GL_COPY_WRITE_BUFFER = 0x8f37;

	private ARBCopyBuffer() {
	}


	public static void glCopyBufferSubData(int readTarget, int writeTarget, long readOffset, long writeOffset, long size) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_copy_buffer_glCopyBufferSubData_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglCopyBufferSubData(readTarget, writeTarget, readOffset, writeOffset, size, function_pointer);
	}
	private static native void nglCopyBufferSubData(int readTarget, int writeTarget, long readOffset, long writeOffset, long size, long function_pointer);
}
