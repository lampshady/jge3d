/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class ARBShaderSubroutine {
	/**
	 * Accepted by the &lt;pname&gt; parameter of GetProgramStageiv: 
	 */
	public static final int GL_ACTIVE_SUBROUTINES = 0x8de5;
	public static final int GL_ACTIVE_SUBROUTINE_UNIFORMS = 0x8de6;
	public static final int GL_ACTIVE_SUBROUTINE_UNIFORM_LOCATIONS = 0x8e47;
	public static final int GL_ACTIVE_SUBROUTINE_MAX_LENGTH = 0x8e48;
	public static final int GL_ACTIVE_SUBROUTINE_UNIFORM_MAX_LENGTH = 0x8e49;
	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv,
	 *  GetFloatv, GetDoublev, and GetInteger64v:
	 */
	public static final int GL_MAX_SUBROUTINES = 0x8de7;
	public static final int GL_MAX_SUBROUTINE_UNIFORM_LOCATIONS = 0x8de8;
	/**
	 * Accepted by the &lt;pname&gt; parameter of GetActiveSubroutineUniformiv: 
	 */
	public static final int GL_NUM_COMPATIBLE_SUBROUTINES = 0x8e4a;
	public static final int GL_COMPATIBLE_SUBROUTINES = 0x8e4b;
	public static final int GL_UNIFORM_SIZE = 0x8a38;
	public static final int GL_UNIFORM_NAME_LENGTH = 0x8a39;

	private ARBShaderSubroutine() {
	}


	public static int glGetSubroutineUniformLocation(int program, int shadertype, ByteBuffer name) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_shader_subroutine_glGetSubroutineUniformLocation_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(name);
		BufferChecks.checkNullTerminated(name);
		int __result = nglGetSubroutineUniformLocation(program, shadertype, name, name.position(), function_pointer);
		return __result;
	}
	private static native int nglGetSubroutineUniformLocation(int program, int shadertype, ByteBuffer name, int name_position, long function_pointer);

	public static int glGetSubroutineIndex(int program, int shadertype, ByteBuffer name) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_shader_subroutine_glGetSubroutineIndex_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(name);
		BufferChecks.checkNullTerminated(name);
		int __result = nglGetSubroutineIndex(program, shadertype, name, name.position(), function_pointer);
		return __result;
	}
	private static native int nglGetSubroutineIndex(int program, int shadertype, ByteBuffer name, int name_position, long function_pointer);

	public static void glGetActiveSubroutineUniform(int program, int shadertype, int index, int pname, IntBuffer values) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_shader_subroutine_glGetActiveSubroutineUniformiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(values, 1);
		nglGetActiveSubroutineUniformiv(program, shadertype, index, pname, values, values.position(), function_pointer);
	}
	private static native void nglGetActiveSubroutineUniformiv(int program, int shadertype, int index, int pname, IntBuffer values, int values_position, long function_pointer);

	/** Overloads glGetActiveSubroutineUniformiv */
	public static int glGetActiveSubroutineUniform(int program, int shadertype, int index, int pname) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_shader_subroutine_glGetActiveSubroutineUniformiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer values = APIUtils.getBufferInt();
		nglGetActiveSubroutineUniformiv(program, shadertype, index, pname, values, values.position(), function_pointer);
		return values.get(0);
	}

	public static void glGetActiveSubroutineUniformName(int program, int shadertype, int index, IntBuffer length, ByteBuffer name) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_shader_subroutine_glGetActiveSubroutineUniformName_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		if (length != null)
			BufferChecks.checkBuffer(length, 1);
		BufferChecks.checkDirect(name);
		nglGetActiveSubroutineUniformName(program, shadertype, index, (name.remaining()), length, length != null ? length.position() : 0, name, name.position(), function_pointer);
	}
	private static native void nglGetActiveSubroutineUniformName(int program, int shadertype, int index, int bufsize, IntBuffer length, int length_position, ByteBuffer name, int name_position, long function_pointer);

	/** Overloads glGetActiveSubroutineUniformName */
	public static String glGetActiveSubroutineUniformName(int program, int shadertype, int index, int bufsize) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_shader_subroutine_glGetActiveSubroutineUniformName_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer name_length = APIUtils.getLengths();
		ByteBuffer name = APIUtils.getBufferByte(bufsize);
		nglGetActiveSubroutineUniformName(program, shadertype, index, bufsize, name_length, 0, name, name.position(), function_pointer);
		name.limit(name_length.get(0));
		return APIUtils.getString(name);
	}

	public static void glGetActiveSubroutineName(int program, int shadertype, int index, IntBuffer length, ByteBuffer name) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_shader_subroutine_glGetActiveSubroutineName_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		if (length != null)
			BufferChecks.checkBuffer(length, 1);
		BufferChecks.checkDirect(name);
		nglGetActiveSubroutineName(program, shadertype, index, (name.remaining()), length, length != null ? length.position() : 0, name, name.position(), function_pointer);
	}
	private static native void nglGetActiveSubroutineName(int program, int shadertype, int index, int bufsize, IntBuffer length, int length_position, ByteBuffer name, int name_position, long function_pointer);

	/** Overloads glGetActiveSubroutineName */
	public static String glGetActiveSubroutineName(int program, int shadertype, int index, int bufsize) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_shader_subroutine_glGetActiveSubroutineName_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer name_length = APIUtils.getLengths();
		ByteBuffer name = APIUtils.getBufferByte(bufsize);
		nglGetActiveSubroutineName(program, shadertype, index, bufsize, name_length, 0, name, name.position(), function_pointer);
		name.limit(name_length.get(0));
		return APIUtils.getString(name);
	}

	public static void glUniformSubroutinesu(int shadertype, IntBuffer indices) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_shader_subroutine_glUniformSubroutinesuiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(indices);
		nglUniformSubroutinesuiv(shadertype, (indices.remaining()), indices, indices.position(), function_pointer);
	}
	private static native void nglUniformSubroutinesuiv(int shadertype, int count, IntBuffer indices, int indices_position, long function_pointer);

	public static void glGetUniformSubroutineu(int shadertype, int location, IntBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_shader_subroutine_glGetUniformSubroutineuiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 1);
		nglGetUniformSubroutineuiv(shadertype, location, params, params.position(), function_pointer);
	}
	private static native void nglGetUniformSubroutineuiv(int shadertype, int location, IntBuffer params, int params_position, long function_pointer);

	/** Overloads glGetUniformSubroutineuiv */
	public static int glGetUniformSubroutineu(int shadertype, int location) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_shader_subroutine_glGetUniformSubroutineuiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer params = APIUtils.getBufferInt();
		nglGetUniformSubroutineuiv(shadertype, location, params, params.position(), function_pointer);
		return params.get(0);
	}

	public static void glGetProgramStage(int program, int shadertype, int pname, IntBuffer values) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_shader_subroutine_glGetProgramStageiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(values, 1);
		nglGetProgramStageiv(program, shadertype, pname, values, values.position(), function_pointer);
	}
	private static native void nglGetProgramStageiv(int program, int shadertype, int pname, IntBuffer values, int values_position, long function_pointer);

	/** Overloads glGetProgramStageiv */
	public static int glGetProgramStage(int program, int shadertype, int pname) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_shader_subroutine_glGetProgramStageiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer values = APIUtils.getBufferInt();
		nglGetProgramStageiv(program, shadertype, pname, values, values.position(), function_pointer);
		return values.get(0);
	}
}
