/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class EXTTextureSnorm {
	/**
	 * Accepted by the &lt;internalFormat&gt; parameter of TexImage1D,
	 * TexImage2D, and TexImage3D:
	 */
	public static final int GL_RED_SNORM = 0x8f90;
	public static final int GL_RG_SNORM = 0x8f91;
	public static final int GL_RGB_SNORM = 0x8f92;
	public static final int GL_RGBA_SNORM = 0x8f93;
	public static final int GL_ALPHA_SNORM = 0x9010;
	public static final int GL_LUMINANCE_SNORM = 0x9011;
	public static final int GL_LUMINANCE_ALPHA_SNORM = 0x9012;
	public static final int GL_INTENSITY_SNORM = 0x9013;
	public static final int GL_R8_SNORM = 0x8f94;
	public static final int GL_RG8_SNORM = 0x8f95;
	public static final int GL_RGB8_SNORM = 0x8f96;
	public static final int GL_RGBA8_SNORM = 0x8f97;
	public static final int GL_ALPHA8_SNORM = 0x9014;
	public static final int GL_LUMINANCE8_SNORM = 0x9015;
	public static final int GL_LUMINANCE8_ALPHA8_SNORM = 0x9016;
	public static final int GL_INTENSITY8_SNORM = 0x9017;
	public static final int GL_R16_SNORM = 0x8f98;
	public static final int GL_RG16_SNORM = 0x8f99;
	public static final int GL_RGB16_SNORM = 0x8f9a;
	public static final int GL_RGBA16_SNORM = 0x8f9b;
	public static final int GL_ALPHA16_SNORM = 0x9018;
	public static final int GL_LUMINANCE16_SNORM = 0x9019;
	public static final int GL_LUMINANCE16_ALPHA16_SNORM = 0x901a;
	public static final int GL_INTENSITY16_SNORM = 0x901b;
	/**
	 *Returned by GetTexLevelParmeter 
	 */
	public static final int GL_SIGNED_NORMALIZED = 0x8f9c;

	private EXTTextureSnorm() {
	}

}
