/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class NVVertexProgram2Option {
	/**
	 * Accepted by the &lt;pname&gt; parameter of GetProgramivARB:
	 */
	public static final int GL_MAX_PROGRAM_EXEC_INSTRUCTIONS_NV = 0x88f4;
	public static final int GL_MAX_PROGRAM_CALL_DEPTH_NV = 0x88f5;

	private NVVertexProgram2Option() {
	}

}
