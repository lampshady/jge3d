/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class ARBSeamlessCubeMap {
	/**
	 *  Accepted by the &lt;cap&gt; parameter of Enable, Disable and IsEnabled,
	 *  and by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv, GetFloatv
	 *  and GetDoublev:
	 */
	public static final int GL_TEXTURE_CUBE_MAP_SEAMLESS = 0x884f;

	private ARBSeamlessCubeMap() {
	}

}
