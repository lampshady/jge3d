/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class APPLEFence {
	/**
	 * Accepted by the &lt;object&gt; parameter of TestObjectAPPLE and FinishObjectAPPLE: 
	 */
	public static final int GL_DRAW_PIXELS_APPLE = 0x8a0a;
	public static final int GL_FENCE_APPLE = 0x8a0b;

	private APPLEFence() {
	}


	public static void glGenFencesAPPLE(IntBuffer fences) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.APPLE_fence_glGenFencesAPPLE_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(fences);
		nglGenFencesAPPLE((fences.remaining()), fences, fences.position(), function_pointer);
	}
	private static native void nglGenFencesAPPLE(int n, IntBuffer fences, int fences_position, long function_pointer);

	/** Overloads glGenFencesAPPLE */
	public static int glGenFencesAPPLE() {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.APPLE_fence_glGenFencesAPPLE_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer fences = APIUtils.getBufferInt();
		nglGenFencesAPPLE(1, fences, fences.position(), function_pointer);
		return fences.get(0);
	}

	public static void glDeleteFencesAPPLE(IntBuffer fences) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.APPLE_fence_glDeleteFencesAPPLE_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(fences);
		nglDeleteFencesAPPLE((fences.remaining()), fences, fences.position(), function_pointer);
	}
	private static native void nglDeleteFencesAPPLE(int n, IntBuffer fences, int fences_position, long function_pointer);

	/** Overloads glDeleteFencesAPPLE */
	public static void glDeleteFencesAPPLE(int fence) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.APPLE_fence_glDeleteFencesAPPLE_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglDeleteFencesAPPLE(1, APIUtils.getBufferInt().put(0, fence), 0, function_pointer);
	}

	public static void glSetFenceAPPLE(int fence) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.APPLE_fence_glSetFenceAPPLE_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglSetFenceAPPLE(fence, function_pointer);
	}
	private static native void nglSetFenceAPPLE(int fence, long function_pointer);

	public static boolean glIsFenceAPPLE(int fence) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.APPLE_fence_glIsFenceAPPLE_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		boolean __result = nglIsFenceAPPLE(fence, function_pointer);
		return __result;
	}
	private static native boolean nglIsFenceAPPLE(int fence, long function_pointer);

	public static boolean glTestFenceAPPLE(int fence) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.APPLE_fence_glTestFenceAPPLE_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		boolean __result = nglTestFenceAPPLE(fence, function_pointer);
		return __result;
	}
	private static native boolean nglTestFenceAPPLE(int fence, long function_pointer);

	public static void glFinishFenceAPPLE(int fence) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.APPLE_fence_glFinishFenceAPPLE_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglFinishFenceAPPLE(fence, function_pointer);
	}
	private static native void nglFinishFenceAPPLE(int fence, long function_pointer);

	public static boolean glTestObjectAPPLE(int object, int name) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.APPLE_fence_glTestObjectAPPLE_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		boolean __result = nglTestObjectAPPLE(object, name, function_pointer);
		return __result;
	}
	private static native boolean nglTestObjectAPPLE(int object, int name, long function_pointer);

	public static void glFinishObjectAPPLE(int object, int name) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.APPLE_fence_glFinishObjectAPPLE_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglFinishObjectAPPLE(object, name, function_pointer);
	}
	private static native void nglFinishObjectAPPLE(int object, int name, long function_pointer);
}
