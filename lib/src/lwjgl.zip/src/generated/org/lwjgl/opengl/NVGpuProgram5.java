/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class NVGpuProgram5 {
	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv,
	 *  GetFloatv, and GetDoublev:
	 */
	public static final int GL_MAX_GEOMETRY_PROGRAM_INVOCATIONS_NV = 0x8e5a;
	public static final int GL_MIN_FRAGMENT_INTERPOLATION_OFFSET_NV = 0x8e5b;
	public static final int GL_MAX_FRAGMENT_INTERPOLATION_OFFSET_NV = 0x8e5c;
	public static final int GL_FRAGMENT_PROGRAM_INTERPOLATION_OFFSET_BITS_NV = 0x8e5d;

	private NVGpuProgram5() {
	}

}
