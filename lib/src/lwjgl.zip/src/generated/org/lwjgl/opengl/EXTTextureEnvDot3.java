/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class EXTTextureEnvDot3 {
	public static final int GL_DOT3_RGB_EXT = 0x8740;
	public static final int GL_DOT3_RGBA_EXT = 0x8741;

	private EXTTextureEnvDot3() {
	}

}
