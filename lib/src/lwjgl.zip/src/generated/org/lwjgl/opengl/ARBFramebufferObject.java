/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class ARBFramebufferObject {
	/**
	 *  Accepted by the &lt;target&gt; parameter of BindFramebuffer,
	 *  CheckFramebufferStatus, FramebufferTexture{1D|2D|3D},
	 *  FramebufferRenderbuffer, and
	 *  GetFramebufferAttachmentParameteriv:
	 */
	public static final int GL_FRAMEBUFFER = 0x8d40;
	public static final int GL_READ_FRAMEBUFFER = 0x8ca8;
	public static final int GL_DRAW_FRAMEBUFFER = 0x8ca9;
	/**
	 *  Accepted by the &lt;target&gt; parameter of BindRenderbuffer,
	 *  RenderbufferStorage, and GetRenderbufferParameteriv, and
	 *  returned by GetFramebufferAttachmentParameteriv:
	 */
	public static final int GL_RENDERBUFFER = 0x8d41;
	/**
	 *  Accepted by the &lt;internalformat&gt; parameter of
	 *  RenderbufferStorage:
	 */
	public static final int GL_STENCIL_INDEX1 = 0x8d46;
	public static final int GL_STENCIL_INDEX4 = 0x8d47;
	public static final int GL_STENCIL_INDEX8 = 0x8d48;
	public static final int GL_STENCIL_INDEX16 = 0x8d49;
	/**
	 * Accepted by the &lt;pname&gt; parameter of GetRenderbufferParameteriv: 
	 */
	public static final int GL_RENDERBUFFER_WIDTH = 0x8d42;
	public static final int GL_RENDERBUFFER_HEIGHT = 0x8d43;
	public static final int GL_RENDERBUFFER_INTERNAL_FORMAT = 0x8d44;
	public static final int GL_RENDERBUFFER_RED_SIZE = 0x8d50;
	public static final int GL_RENDERBUFFER_GREEN_SIZE = 0x8d51;
	public static final int GL_RENDERBUFFER_BLUE_SIZE = 0x8d52;
	public static final int GL_RENDERBUFFER_ALPHA_SIZE = 0x8d53;
	public static final int GL_RENDERBUFFER_DEPTH_SIZE = 0x8d54;
	public static final int GL_RENDERBUFFER_STENCIL_SIZE = 0x8d55;
	public static final int GL_RENDERBUFFER_SAMPLES = 0x8cab;
	/**
	 *  Accepted by the &lt;pname&gt; parameter of
	 *  GetFramebufferAttachmentParameteriv:
	 */
	public static final int GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE = 0x8cd0;
	public static final int GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME = 0x8cd1;
	public static final int GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL = 0x8cd2;
	public static final int GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE = 0x8cd3;
	public static final int GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER = 0x8cd4;
	public static final int GL_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING = 0x8210;
	public static final int GL_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE = 0x8211;
	public static final int GL_FRAMEBUFFER_ATTACHMENT_RED_SIZE = 0x8212;
	public static final int GL_FRAMEBUFFER_ATTACHMENT_GREEN_SIZE = 0x8213;
	public static final int GL_FRAMEBUFFER_ATTACHMENT_BLUE_SIZE = 0x8214;
	public static final int GL_FRAMEBUFFER_ATTACHMENT_ALPHA_SIZE = 0x8215;
	public static final int GL_FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE = 0x8216;
	public static final int GL_FRAMEBUFFER_ATTACHMENT_STENCIL_SIZE = 0x8217;
	/**
	 * Returned in &lt;params&gt; by GetFramebufferAttachmentParameteriv: 
	 */
	public static final int GL_SRGB = 0x8c40;
	public static final int GL_UNSIGNED_NORMALIZED = 0x8c17;
	public static final int GL_FRAMEBUFFER_DEFAULT = 0x8218;
	public static final int GL_INDEX = 0x8222;
	/**
	 *  Accepted by the &lt;attachment&gt; parameter of
	 *  FramebufferTexture{1D|2D|3D}, FramebufferRenderbuffer, and
	 *  GetFramebufferAttachmentParameteriv
	 */
	public static final int GL_COLOR_ATTACHMENT0 = 0x8ce0;
	public static final int GL_COLOR_ATTACHMENT1 = 0x8ce1;
	public static final int GL_COLOR_ATTACHMENT2 = 0x8ce2;
	public static final int GL_COLOR_ATTACHMENT3 = 0x8ce3;
	public static final int GL_COLOR_ATTACHMENT4 = 0x8ce4;
	public static final int GL_COLOR_ATTACHMENT5 = 0x8ce5;
	public static final int GL_COLOR_ATTACHMENT6 = 0x8ce6;
	public static final int GL_COLOR_ATTACHMENT7 = 0x8ce7;
	public static final int GL_COLOR_ATTACHMENT8 = 0x8ce8;
	public static final int GL_COLOR_ATTACHMENT9 = 0x8ce9;
	public static final int GL_COLOR_ATTACHMENT10 = 0x8cea;
	public static final int GL_COLOR_ATTACHMENT11 = 0x8ceb;
	public static final int GL_COLOR_ATTACHMENT12 = 0x8cec;
	public static final int GL_COLOR_ATTACHMENT13 = 0x8ced;
	public static final int GL_COLOR_ATTACHMENT14 = 0x8cee;
	public static final int GL_COLOR_ATTACHMENT15 = 0x8cef;
	public static final int GL_DEPTH_ATTACHMENT = 0x8d00;
	public static final int GL_STENCIL_ATTACHMENT = 0x8d20;
	public static final int GL_DEPTH_STENCIL_ATTACHMENT = 0x821a;
	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv,
	 *  GetFloatv, and GetDoublev:
	 */
	public static final int GL_MAX_SAMPLES = 0x8d57;
	/**
	 * Returned by CheckFramebufferStatus(): 
	 */
	public static final int GL_FRAMEBUFFER_COMPLETE = 0x8cd5;
	public static final int GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT = 0x8cd6;
	public static final int GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT = 0x8cd7;
	public static final int GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER = 0x8cdb;
	public static final int GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER = 0x8cdc;
	public static final int GL_FRAMEBUFFER_UNSUPPORTED = 0x8cdd;
	public static final int GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE = 0x8d56;
	public static final int GL_FRAMEBUFFER_UNDEFINED = 0x8219;
	/**
	 *  Accepted by the &lt;pname&gt; parameters of GetIntegerv, GetFloatv,
	 *  and GetDoublev:
	 */
	public static final int GL_FRAMEBUFFER_BINDING = 0x8ca6;
	public static final int GL_DRAW_FRAMEBUFFER_BINDING = 0x8ca6;
	public static final int GL_READ_FRAMEBUFFER_BINDING = 0x8caa;
	public static final int GL_RENDERBUFFER_BINDING = 0x8ca7;
	public static final int GL_MAX_COLOR_ATTACHMENTS = 0x8cdf;
	public static final int GL_MAX_RENDERBUFFER_SIZE = 0x84e8;
	/**
	 * Returned by GetError(): 
	 */
	public static final int GL_INVALID_FRAMEBUFFER_OPERATION = 0x506;
	/**
	 *  Accepted by the &lt;format&gt; parameter of DrawPixels, ReadPixels,
	 *  TexImage1D, TexImage2D, TexImage3D, TexSubImage1D, TexSubImage2D,
	 *  TexSubImage3D, and GetTexImage, by the &lt;type&gt; parameter of
	 *  CopyPixels, by the &lt;internalformat&gt; parameter of TexImage1D,
	 *  TexImage2D, TexImage3D, CopyTexImage1D, CopyTexImage2D, and
	 *  RenderbufferStorage, and returned in the &lt;data&gt; parameter of
	 *  GetTexLevelParameter and GetRenderbufferParameteriv:
	 */
	public static final int GL_DEPTH_STENCIL = 0x84f9;
	/**
	 *  Accepted by the &lt;type&gt; parameter of DrawPixels, ReadPixels,
	 *  TexImage1D, TexImage2D, TexImage3D, TexSubImage1D, TexSubImage2D,
	 *  TexSubImage3D, and GetTexImage:
	 */
	public static final int GL_UNSIGNED_INT_24_8 = 0x84fa;
	/**
	 *  Accepted by the &lt;internalformat&gt; parameter of TexImage1D,
	 *  TexImage2D, TexImage3D, CopyTexImage1D, CopyTexImage2D, and
	 *  RenderbufferStorage, and returned in the &lt;data&gt; parameter of
	 *  GetTexLevelParameter and GetRenderbufferParameteriv:
	 */
	public static final int GL_DEPTH24_STENCIL8 = 0x88f0;
	/**
	 * Accepted by the &lt;value&gt; parameter of GetTexLevelParameter: 
	 */
	public static final int GL_TEXTURE_STENCIL_SIZE = 0x88f1;

	private ARBFramebufferObject() {
	}


	public static boolean glIsRenderbuffer(int renderbuffer) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glIsRenderbuffer_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		boolean __result = nglIsRenderbuffer(renderbuffer, function_pointer);
		return __result;
	}
	private static native boolean nglIsRenderbuffer(int renderbuffer, long function_pointer);

	public static void glBindRenderbuffer(int target, int renderbuffer) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glBindRenderbuffer_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglBindRenderbuffer(target, renderbuffer, function_pointer);
	}
	private static native void nglBindRenderbuffer(int target, int renderbuffer, long function_pointer);

	public static void glDeleteRenderbuffers(IntBuffer renderbuffers) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glDeleteRenderbuffers_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(renderbuffers);
		nglDeleteRenderbuffers((renderbuffers.remaining()), renderbuffers, renderbuffers.position(), function_pointer);
	}
	private static native void nglDeleteRenderbuffers(int n, IntBuffer renderbuffers, int renderbuffers_position, long function_pointer);

	/** Overloads glDeleteRenderbuffers */
	public static void glDeleteRenderbuffers(int renderbuffer) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glDeleteRenderbuffers_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglDeleteRenderbuffers(1, APIUtils.getBufferInt().put(0, renderbuffer), 0, function_pointer);
	}

	public static void glGenRenderbuffers(IntBuffer renderbuffers) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glGenRenderbuffers_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(renderbuffers);
		nglGenRenderbuffers((renderbuffers.remaining()), renderbuffers, renderbuffers.position(), function_pointer);
	}
	private static native void nglGenRenderbuffers(int n, IntBuffer renderbuffers, int renderbuffers_position, long function_pointer);

	/** Overloads glGenRenderbuffers */
	public static int glGenRenderbuffers() {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glGenRenderbuffers_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer renderbuffers = APIUtils.getBufferInt();
		nglGenRenderbuffers(1, renderbuffers, renderbuffers.position(), function_pointer);
		return renderbuffers.get(0);
	}

	public static void glRenderbufferStorage(int target, int internalformat, int width, int height) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glRenderbufferStorage_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglRenderbufferStorage(target, internalformat, width, height, function_pointer);
	}
	private static native void nglRenderbufferStorage(int target, int internalformat, int width, int height, long function_pointer);

	public static void glRenderbufferStorageMultisample(int target, int samples, int internalformat, int width, int height) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glRenderbufferStorageMultisample_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglRenderbufferStorageMultisample(target, samples, internalformat, width, height, function_pointer);
	}
	private static native void nglRenderbufferStorageMultisample(int target, int samples, int internalformat, int width, int height, long function_pointer);

	public static void glGetRenderbufferParameter(int target, int pname, IntBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glGetRenderbufferParameteriv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 4);
		nglGetRenderbufferParameteriv(target, pname, params, params.position(), function_pointer);
	}
	private static native void nglGetRenderbufferParameteriv(int target, int pname, IntBuffer params, int params_position, long function_pointer);

	/** Overloads glGetRenderbufferParameteriv */
	public static int glGetRenderbufferParameter(int target, int pname) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glGetRenderbufferParameteriv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer params = APIUtils.getBufferInt();
		nglGetRenderbufferParameteriv(target, pname, params, params.position(), function_pointer);
		return params.get(0);
	}

	public static boolean glIsFramebuffer(int framebuffer) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glIsFramebuffer_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		boolean __result = nglIsFramebuffer(framebuffer, function_pointer);
		return __result;
	}
	private static native boolean nglIsFramebuffer(int framebuffer, long function_pointer);

	public static void glBindFramebuffer(int target, int framebuffer) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glBindFramebuffer_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglBindFramebuffer(target, framebuffer, function_pointer);
	}
	private static native void nglBindFramebuffer(int target, int framebuffer, long function_pointer);

	public static void glDeleteFramebuffers(IntBuffer framebuffers) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glDeleteFramebuffers_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(framebuffers);
		nglDeleteFramebuffers((framebuffers.remaining()), framebuffers, framebuffers.position(), function_pointer);
	}
	private static native void nglDeleteFramebuffers(int n, IntBuffer framebuffers, int framebuffers_position, long function_pointer);

	/** Overloads glDeleteFramebuffers */
	public static void glDeleteFramebuffers(int framebuffer) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glDeleteFramebuffers_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglDeleteFramebuffers(1, APIUtils.getBufferInt().put(0, framebuffer), 0, function_pointer);
	}

	public static void glGenFramebuffers(IntBuffer framebuffers) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glGenFramebuffers_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(framebuffers);
		nglGenFramebuffers((framebuffers.remaining()), framebuffers, framebuffers.position(), function_pointer);
	}
	private static native void nglGenFramebuffers(int n, IntBuffer framebuffers, int framebuffers_position, long function_pointer);

	/** Overloads glGenFramebuffers */
	public static int glGenFramebuffers() {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glGenFramebuffers_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer framebuffers = APIUtils.getBufferInt();
		nglGenFramebuffers(1, framebuffers, framebuffers.position(), function_pointer);
		return framebuffers.get(0);
	}

	public static int glCheckFramebufferStatus(int target) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glCheckFramebufferStatus_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		int __result = nglCheckFramebufferStatus(target, function_pointer);
		return __result;
	}
	private static native int nglCheckFramebufferStatus(int target, long function_pointer);

	public static void glFramebufferTexture1D(int target, int attachment, int textarget, int texture, int level) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glFramebufferTexture1D_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglFramebufferTexture1D(target, attachment, textarget, texture, level, function_pointer);
	}
	private static native void nglFramebufferTexture1D(int target, int attachment, int textarget, int texture, int level, long function_pointer);

	public static void glFramebufferTexture2D(int target, int attachment, int textarget, int texture, int level) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glFramebufferTexture2D_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglFramebufferTexture2D(target, attachment, textarget, texture, level, function_pointer);
	}
	private static native void nglFramebufferTexture2D(int target, int attachment, int textarget, int texture, int level, long function_pointer);

	public static void glFramebufferTexture3D(int target, int attachment, int textarget, int texture, int level, int layer) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glFramebufferTexture3D_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglFramebufferTexture3D(target, attachment, textarget, texture, level, layer, function_pointer);
	}
	private static native void nglFramebufferTexture3D(int target, int attachment, int textarget, int texture, int level, int layer, long function_pointer);

	public static void glFramebufferTextureLayer(int target, int attachment, int texture, int level, int layer) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glFramebufferTextureLayer_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglFramebufferTextureLayer(target, attachment, texture, level, layer, function_pointer);
	}
	private static native void nglFramebufferTextureLayer(int target, int attachment, int texture, int level, int layer, long function_pointer);

	public static void glFramebufferRenderbuffer(int target, int attachment, int renderbuffertarget, int renderbuffer) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glFramebufferRenderbuffer_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglFramebufferRenderbuffer(target, attachment, renderbuffertarget, renderbuffer, function_pointer);
	}
	private static native void nglFramebufferRenderbuffer(int target, int attachment, int renderbuffertarget, int renderbuffer, long function_pointer);

	public static void glGetFramebufferAttachmentParameter(int target, int attachment, int pname, IntBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glGetFramebufferAttachmentParameteriv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 4);
		nglGetFramebufferAttachmentParameteriv(target, attachment, pname, params, params.position(), function_pointer);
	}
	private static native void nglGetFramebufferAttachmentParameteriv(int target, int attachment, int pname, IntBuffer params, int params_position, long function_pointer);

	/** Overloads glGetFramebufferAttachmentParameteriv */
	public static int glGetFramebufferAttachmentParameter(int target, int attachment, int pname) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glGetFramebufferAttachmentParameteriv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer params = APIUtils.getBufferInt();
		nglGetFramebufferAttachmentParameteriv(target, attachment, pname, params, params.position(), function_pointer);
		return params.get(0);
	}

	public static void glBlitFramebuffer(int srcX0, int srcY0, int srcX1, int srcY1, int dstX0, int dstY0, int dstX1, int dstY1, int mask, int filter) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glBlitFramebuffer_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglBlitFramebuffer(srcX0, srcY0, srcX1, srcY1, dstX0, dstY0, dstX1, dstY1, mask, filter, function_pointer);
	}
	private static native void nglBlitFramebuffer(int srcX0, int srcY0, int srcX1, int srcY1, int dstX0, int dstY0, int dstX1, int dstY1, int mask, int filter, long function_pointer);

	public static void glGenerateMipmap(int target) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_framebuffer_object_glGenerateMipmap_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglGenerateMipmap(target, function_pointer);
	}
	private static native void nglGenerateMipmap(int target, long function_pointer);
}
