/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class ARBDrawIndirect {
	/**
	 *  Accepted by the &lt;target&gt; parameters of BindBuffer, BufferData,
	 *  BufferSubData, MapBuffer, UnmapBuffer, GetBufferSubData,
	 *  GetBufferPointerv, MapBufferRange, FlushMappedBufferRange,
	 *  GetBufferParameteriv, BindBufferRange, BindBufferBase, and
	 *  CopyBufferSubData:
	 */
	public static final int GL_DRAW_INDIRECT_BUFFER = 0x8f3f;
	/**
	 *  Accepted by the &lt;value&gt; parameter of GetIntegerv, GetBooleanv, GetFloatv,
	 *  and GetDoublev:
	 */
	public static final int GL_DRAW_INDIRECT_BUFFER_BINDING = 0x8f43;

	private ARBDrawIndirect() {
	}


	public static void glDrawArraysIndirect(int mode, IntBuffer indirect) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_draw_indirect_glDrawArraysIndirect_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureIndirectBOdisabled(caps);
		BufferChecks.checkBuffer(indirect, 4);
		BufferChecks.checkNullTerminated(indirect);
		nglDrawArraysIndirect(mode, indirect, indirect.position(), function_pointer);
	}
	private static native void nglDrawArraysIndirect(int mode, IntBuffer indirect, int indirect_position, long function_pointer);
	public static void glDrawArraysIndirect(int mode, long indirect_buffer_offset) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_draw_indirect_glDrawArraysIndirect_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureIndirectBOenabled(caps);
		nglDrawArraysIndirectBO(mode, indirect_buffer_offset, function_pointer);
	}
	private static native void nglDrawArraysIndirectBO(int mode, long indirect_buffer_offset, long function_pointer);

	public static void glDrawElementsIndirect(int mode, int type, IntBuffer indirect) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_draw_indirect_glDrawElementsIndirect_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureIndirectBOdisabled(caps);
		BufferChecks.checkBuffer(indirect, 5);
		BufferChecks.checkNullTerminated(indirect);
		nglDrawElementsIndirect(mode, type, indirect, indirect.position(), function_pointer);
	}
	private static native void nglDrawElementsIndirect(int mode, int type, IntBuffer indirect, int indirect_position, long function_pointer);
	public static void glDrawElementsIndirect(int mode, int type, long indirect_buffer_offset) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_draw_indirect_glDrawElementsIndirect_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureIndirectBOenabled(caps);
		nglDrawElementsIndirectBO(mode, type, indirect_buffer_offset, function_pointer);
	}
	private static native void nglDrawElementsIndirectBO(int mode, int type, long indirect_buffer_offset, long function_pointer);
}
