/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class EXTShaderImageLoadStore {
	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv,
	 *  GetFloatv, and GetDoublev:
	 */
	public static final int GL_MAX_IMAGE_UNITS_EXT = 0x8f38;
	public static final int GL_MAX_COMBINED_IMAGE_UNITS_AND_FRAGMENT_OUTPUTS_EXT = 0x8f39;
	public static final int GL_MAX_IMAGE_SAMPLES_EXT = 0x906d;
	/**
	 * Accepted by the &lt;target&gt; parameter of GetIntegeri_v and GetBooleani_v: 
	 */
	public static final int GL_IMAGE_BINDING_NAME_EXT = 0x8f3a;
	public static final int GL_IMAGE_BINDING_LEVEL_EXT = 0x8f3b;
	public static final int GL_IMAGE_BINDING_LAYERED_EXT = 0x8f3c;
	public static final int GL_IMAGE_BINDING_LAYER_EXT = 0x8f3d;
	public static final int GL_IMAGE_BINDING_ACCESS_EXT = 0x8f3e;
	public static final int GL_IMAGE_BINDING_FORMAT_EXT = 0x906e;
	/**
	 * Accepted by the &lt;barriers&gt; parameter of MemoryBarrierEXT: 
	 */
	public static final int GL_VERTEX_ATTRIB_ARRAY_BARRIER_BIT_EXT = 0x1;
	public static final int GL_ELEMENT_ARRAY_BARRIER_BIT_EXT = 0x2;
	public static final int GL_UNIFORM_BARRIER_BIT_EXT = 0x4;
	public static final int GL_TEXTURE_FETCH_BARRIER_BIT_EXT = 0x8;
	public static final int GL_SHADER_IMAGE_ACCESS_BARRIER_BIT_EXT = 0x20;
	public static final int GL_COMMAND_BARRIER_BIT_EXT = 0x40;
	public static final int GL_PIXEL_BUFFER_BARRIER_BIT_EXT = 0x80;
	public static final int GL_TEXTURE_UPDATE_BARRIER_BIT_EXT = 0x100;
	public static final int GL_BUFFER_UPDATE_BARRIER_BIT_EXT = 0x200;
	public static final int GL_FRAMEBUFFER_BARRIER_BIT_EXT = 0x400;
	public static final int GL_TRANSFORM_FEEDBACK_BARRIER_BIT_EXT = 0x800;
	public static final int GL_ATOMIC_COUNTER_BARRIER_BIT_EXT = 0x1000;
	public static final int GL_ALL_BARRIER_BITS_EXT = 0xffffffff;
	/**
	 * Returned by the &lt;type&gt; parameter of GetActiveUniform: 
	 */
	public static final int GL_IMAGE_1D_EXT = 0x904c;
	public static final int GL_IMAGE_2D_EXT = 0x904d;
	public static final int GL_IMAGE_3D_EXT = 0x904e;
	public static final int GL_IMAGE_2D_RECT_EXT = 0x904f;
	public static final int GL_IMAGE_CUBE_EXT = 0x9050;
	public static final int GL_IMAGE_BUFFER_EXT = 0x9051;
	public static final int GL_IMAGE_1D_ARRAY_EXT = 0x9052;
	public static final int GL_IMAGE_2D_ARRAY_EXT = 0x9053;
	public static final int GL_IMAGE_CUBE_MAP_ARRAY_EXT = 0x9054;
	public static final int GL_IMAGE_2D_MULTISAMPLE_EXT = 0x9055;
	public static final int GL_IMAGE_2D_MULTISAMPLE_ARRAY_EXT = 0x9056;
	public static final int GL_INT_IMAGE_1D_EXT = 0x9057;
	public static final int GL_INT_IMAGE_2D_EXT = 0x9058;
	public static final int GL_INT_IMAGE_3D_EXT = 0x9059;
	public static final int GL_INT_IMAGE_2D_RECT_EXT = 0x905a;
	public static final int GL_INT_IMAGE_CUBE_EXT = 0x905b;
	public static final int GL_INT_IMAGE_BUFFER_EXT = 0x905c;
	public static final int GL_INT_IMAGE_1D_ARRAY_EXT = 0x905d;
	public static final int GL_INT_IMAGE_2D_ARRAY_EXT = 0x905e;
	public static final int GL_INT_IMAGE_CUBE_MAP_ARRAY_EXT = 0x905f;
	public static final int GL_INT_IMAGE_2D_MULTISAMPLE_EXT = 0x9060;
	public static final int GL_INT_IMAGE_2D_MULTISAMPLE_ARRAY_EXT = 0x9061;
	public static final int GL_UNSIGNED_INT_IMAGE_1D_EXT = 0x9062;
	public static final int GL_UNSIGNED_INT_IMAGE_2D_EXT = 0x9063;
	public static final int GL_UNSIGNED_INT_IMAGE_3D_EXT = 0x9064;
	public static final int GL_UNSIGNED_INT_IMAGE_2D_RECT_EXT = 0x9065;
	public static final int GL_UNSIGNED_INT_IMAGE_CUBE_EXT = 0x9066;
	public static final int GL_UNSIGNED_INT_IMAGE_BUFFER_EXT = 0x9067;
	public static final int GL_UNSIGNED_INT_IMAGE_1D_ARRAY_EXT = 0x9068;
	public static final int GL_UNSIGNED_INT_IMAGE_2D_ARRAY_EXT = 0x9069;
	public static final int GL_UNSIGNED_INT_IMAGE_CUBE_MAP_ARRAY_EXT = 0x906a;
	public static final int GL_UNSIGNED_INT_IMAGE_2D_MULTISAMPLE_EXT = 0x906b;
	public static final int GL_UNSIGNED_INT_IMAGE_2D_MULTISAMPLE_ARRAY_EXT = 0x906c;

	private EXTShaderImageLoadStore() {
	}


	public static void glBindImageTextureEXT(int index, int texture, int level, boolean layered, int layer, int access, int format) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.EXT_shader_image_load_store_glBindImageTextureEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglBindImageTextureEXT(index, texture, level, layered, layer, access, format, function_pointer);
	}
	private static native void nglBindImageTextureEXT(int index, int texture, int level, boolean layered, int layer, int access, int format, long function_pointer);

	public static void glMemoryBarrierEXT(int barriers) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.EXT_shader_image_load_store_glMemoryBarrierEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglMemoryBarrierEXT(barriers, function_pointer);
	}
	private static native void nglMemoryBarrierEXT(int barriers, long function_pointer);
}
