/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class ARBTextureFloat {
	/**
	 * Accepted by the &lt;value&gt; parameter of GetTexLevelParameter:
	 */
	public static final int GL_TEXTURE_RED_TYPE_ARB = 0x8c10;
	public static final int GL_TEXTURE_GREEN_TYPE_ARB = 0x8c11;
	public static final int GL_TEXTURE_BLUE_TYPE_ARB = 0x8c12;
	public static final int GL_TEXTURE_ALPHA_TYPE_ARB = 0x8c13;
	public static final int GL_TEXTURE_LUMINANCE_TYPE_ARB = 0x8c14;
	public static final int GL_TEXTURE_INTENSITY_TYPE_ARB = 0x8c15;
	public static final int GL_TEXTURE_DEPTH_TYPE_ARB = 0x8c16;
	/**
	 * Returned by the &lt;params&gt; parameter of GetTexLevelParameter:
	 */
	public static final int GL_UNSIGNED_NORMALIZED_ARB = 0x8c17;
	/**
	 * Accepted by the &lt;internalFormat&gt; parameter of TexImage1D,
	 * TexImage2D, and TexImage3D:
	 */
	public static final int GL_RGBA32F_ARB = 0x8814;
	public static final int GL_RGB32F_ARB = 0x8815;
	public static final int GL_ALPHA32F_ARB = 0x8816;
	public static final int GL_INTENSITY32F_ARB = 0x8817;
	public static final int GL_LUMINANCE32F_ARB = 0x8818;
	public static final int GL_LUMINANCE_ALPHA32F_ARB = 0x8819;
	public static final int GL_RGBA16F_ARB = 0x881a;
	public static final int GL_RGB16F_ARB = 0x881b;
	public static final int GL_ALPHA16F_ARB = 0x881c;
	public static final int GL_INTENSITY16F_ARB = 0x881d;
	public static final int GL_LUMINANCE16F_ARB = 0x881e;
	public static final int GL_LUMINANCE_ALPHA16F_ARB = 0x881f;

	private ARBTextureFloat() {
	}

}
