/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class GREMEDYStringMarker {

	private GREMEDYStringMarker() {
	}


	public static void glStringMarkerGREMEDY(ByteBuffer string) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GREMEDY_string_marker_glStringMarkerGREMEDY_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(string);
		nglStringMarkerGREMEDY((string.remaining()), string, string.position(), function_pointer);
	}
	private static native void nglStringMarkerGREMEDY(int len, ByteBuffer string, int string_position, long function_pointer);
}
