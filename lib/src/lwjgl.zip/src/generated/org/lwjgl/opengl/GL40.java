/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class GL40 {
	/**
	 *  Accepted by the &lt;target&gt; parameters of BindBuffer, BufferData,
	 *  BufferSubData, MapBuffer, UnmapBuffer, GetBufferSubData,
	 *  GetBufferPointerv, MapBufferRange, FlushMappedBufferRange,
	 *  GetBufferParameteriv, BindBufferRange, BindBufferBase, and
	 *  CopyBufferSubData:
	 */
	public static final int GL_DRAW_INDIRECT_BUFFER = 0x8f3f;
	/**
	 *  Accepted by the &lt;value&gt; parameter of GetIntegerv, GetBooleanv, GetFloatv,
	 *  and GetDoublev:
	 */
	public static final int GL_DRAW_INDIRECT_BUFFER_BINDING = 0x8f43;
	/**
	 * Accepted by the &lt;pname&gt; parameter of GetProgramiv: 
	 */
	public static final int GL_GEOMETRY_SHADER_INVOCATIONS = 0x887f;
	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv, GetFloatv,
	 *  GetDoublev, and GetInteger64v:
	 */
	public static final int GL_MAX_GEOMETRY_SHADER_INVOCATIONS = 0x8e5a;
	public static final int GL_MIN_FRAGMENT_INTERPOLATION_OFFSET = 0x8e5b;
	public static final int GL_MAX_FRAGMENT_INTERPOLATION_OFFSET = 0x8e5c;
	public static final int GL_FRAGMENT_INTERPOLATION_OFFSET_BITS = 0x8e5d;
	public static final int GL_MAX_VERTEX_STREAMS = 0x8e71;
	/**
	 *  Returned in the &lt;type&gt; parameter of GetActiveUniform, and
	 *  GetTransformFeedbackVarying:
	 */
	public static final int GL_DOUBLE_VEC2 = 0x8ffc;
	public static final int GL_DOUBLE_VEC3 = 0x8ffd;
	public static final int GL_DOUBLE_VEC4 = 0x8ffe;
	public static final int GL_DOUBLE_MAT2 = 0x8f46;
	public static final int GL_DOUBLE_MAT3 = 0x8f47;
	public static final int GL_DOUBLE_MAT4 = 0x8f48;
	public static final int GL_DOUBLE_MAT2x3 = 0x8f49;
	public static final int GL_DOUBLE_MAT2x4 = 0x8f4a;
	public static final int GL_DOUBLE_MAT3x2 = 0x8f4b;
	public static final int GL_DOUBLE_MAT3x4 = 0x8f4c;
	public static final int GL_DOUBLE_MAT4x2 = 0x8f4d;
	public static final int GL_DOUBLE_MAT4x3 = 0x8f4e;
	/**
	 *  Accepted by the &lt;cap&gt; parameter of Enable, Disable, and IsEnabled,
	 *  and by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv, GetFloatv,
	 *  and GetDoublev:
	 */
	public static final int GL_SAMPLE_SHADING = 0x8c36;
	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetDoublev,
	 *  GetIntegerv, and GetFloatv:
	 */
	public static final int GL_MIN_SAMPLE_SHADING_VALUE = 0x8c37;
	/**
	 * Accepted by the &lt;pname&gt; parameter of GetProgramStageiv: 
	 */
	public static final int GL_ACTIVE_SUBROUTINES = 0x8de5;
	public static final int GL_ACTIVE_SUBROUTINE_UNIFORMS = 0x8de6;
	public static final int GL_ACTIVE_SUBROUTINE_UNIFORM_LOCATIONS = 0x8e47;
	public static final int GL_ACTIVE_SUBROUTINE_MAX_LENGTH = 0x8e48;
	public static final int GL_ACTIVE_SUBROUTINE_UNIFORM_MAX_LENGTH = 0x8e49;
	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv,
	 *  GetFloatv, GetDoublev, and GetInteger64v:
	 */
	public static final int GL_MAX_SUBROUTINES = 0x8de7;
	public static final int GL_MAX_SUBROUTINE_UNIFORM_LOCATIONS = 0x8de8;
	/**
	 * Accepted by the &lt;pname&gt; parameter of GetActiveSubroutineUniformiv: 
	 */
	public static final int GL_NUM_COMPATIBLE_SUBROUTINES = 0x8e4a;
	public static final int GL_COMPATIBLE_SUBROUTINES = 0x8e4b;
	public static final int GL_UNIFORM_SIZE = 0x8a38;
	public static final int GL_UNIFORM_NAME_LENGTH = 0x8a39;
	/**
	 *  Accepted by the &lt;mode&gt; parameter of Begin and all vertex array functions
	 *  that implicitly call Begin:
	 */
	public static final int GL_PATCHES = 0xe;
	/**
	 *  Accepted by the &lt;pname&gt; parameter of PatchParameteri, GetBooleanv,
	 *  GetDoublev, GetFloatv, GetIntegerv, and GetInteger64v:
	 */
	public static final int GL_PATCH_VERTICES = 0x8e72;
	/**
	 *  Accepted by the &lt;pname&gt; parameter of PatchParameterfv, GetBooleanv,
	 *  GetDoublev, GetFloatv, and GetIntegerv, and GetInteger64v:
	 */
	public static final int GL_PATCH_DEFAULT_INNER_LEVEL = 0x8e73;
	public static final int GL_PATCH_DEFAULT_OUTER_LEVEL = 0x8e74;
	/**
	 * Accepted by the &lt;pname&gt; parameter of GetProgramiv: 
	 */
	public static final int GL_TESS_CONTROL_OUTPUT_VERTICES = 0x8e75;
	public static final int GL_TESS_GEN_MODE = 0x8e76;
	public static final int GL_TESS_GEN_SPACING = 0x8e77;
	public static final int GL_TESS_GEN_VERTEX_ORDER = 0x8e78;
	public static final int GL_TESS_GEN_POINT_MODE = 0x8e79;
	/**
	 * Returned by GetProgramiv when &lt;pname&gt; is TESS_GEN_MODE: 
	 */
	public static final int GL_ISOLINES = 0x8e7a;
	/**
	 * Returned by GetProgramiv when &lt;pname&gt; is TESS_GEN_SPACING: 
	 */
	public static final int GL_FRACTIONAL_ODD = 0x8e7b;
	public static final int GL_FRACTIONAL_EVEN = 0x8e7c;
	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetDoublev, GetFloatv,
	 *  GetIntegerv, and GetInteger64v:
	 */
	public static final int GL_MAX_PATCH_VERTICES = 0x8e7d;
	public static final int GL_MAX_TESS_GEN_LEVEL = 0x8e7e;
	public static final int GL_MAX_TESS_CONTROL_UNIFORM_COMPONENTS = 0x8e7f;
	public static final int GL_MAX_TESS_EVALUATION_UNIFORM_COMPONENTS = 0x8e80;
	public static final int GL_MAX_TESS_CONTROL_TEXTURE_IMAGE_UNITS = 0x8e81;
	public static final int GL_MAX_TESS_EVALUATION_TEXTURE_IMAGE_UNITS = 0x8e82;
	public static final int GL_MAX_TESS_CONTROL_OUTPUT_COMPONENTS = 0x8e83;
	public static final int GL_MAX_TESS_PATCH_COMPONENTS = 0x8e84;
	public static final int GL_MAX_TESS_CONTROL_TOTAL_OUTPUT_COMPONENTS = 0x8e85;
	public static final int GL_MAX_TESS_EVALUATION_OUTPUT_COMPONENTS = 0x8e86;
	public static final int GL_MAX_TESS_CONTROL_UNIFORM_BLOCKS = 0x8e89;
	public static final int GL_MAX_TESS_EVALUATION_UNIFORM_BLOCKS = 0x8e8a;
	public static final int GL_MAX_TESS_CONTROL_INPUT_COMPONENTS = 0x886c;
	public static final int GL_MAX_TESS_EVALUATION_INPUT_COMPONENTS = 0x886d;
	public static final int GL_MAX_COMBINED_TESS_CONTROL_UNIFORM_COMPONENTS = 0x8e1e;
	public static final int GL_MAX_COMBINED_TESS_EVALUATION_UNIFORM_COMPONENTS = 0x8e1f;
	/**
	 * Accepted by the &lt;pname&gt; parameter of GetActiveUniformBlockiv: 
	 */
	public static final int GL_UNIFORM_BLOCK_REFERENCED_BY_TESS_CONTROL_SHADER = 0x84f0;
	public static final int GL_UNIFORM_BLOCK_REFERENCED_BY_TESS_EVALUATION_SHADER = 0x84f1;
	/**
	 *  Accepted by the &lt;type&gt; parameter of CreateShader and returned by the
	 *  &lt;params&gt; parameter of GetShaderiv:
	 */
	public static final int GL_TESS_EVALUATION_SHADER = 0x8e87;
	public static final int GL_TESS_CONTROL_SHADER = 0x8e88;
	/**
	 *  Accepted by the &lt;target&gt; parameter of TexParameteri, TexParameteriv,
	 *  TexParameterf, TexParameterfv, BindTexture, and GenerateMipmap:
	 *  <p/>
	 *  Accepted by the &lt;target&gt; parameter of TexImage3D, TexSubImage3D,
	 *  CompressedTeximage3D, CompressedTexSubImage3D and CopyTexSubImage3D:
	 *  <p/>
	 *  Accepted by the &lt;tex&gt; parameter of GetTexImage:
	 */
	public static final int GL_TEXTURE_CUBE_MAP_ARRAY = 0x9009;
	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetDoublev,
	 *  GetIntegerv and GetFloatv:
	 */
	public static final int GL_TEXTURE_BINDING_CUBE_MAP_ARRAY = 0x900a;
	/**
	 *  Accepted by the &lt;target&gt; parameter of TexImage3D, TexSubImage3D,
	 *  CompressedTeximage3D, CompressedTexSubImage3D and CopyTexSubImage3D:
	 */
	public static final int GL_PROXY_TEXTURE_CUBE_MAP_ARRAY = 0x900b;
	/**
	 * Returned by the &lt;type&gt; parameter of GetActiveUniform: 
	 */
	public static final int GL_SAMPLER_CUBE_MAP_ARRAY = 0x900c;
	public static final int GL_SAMPLER_CUBE_MAP_ARRAY_SHADOW = 0x900d;
	public static final int GL_INT_SAMPLER_CUBE_MAP_ARRAY = 0x900e;
	public static final int GL_UNSIGNED_INT_SAMPLER_CUBE_MAP_ARRAY = 0x900f;
	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv,
	 *  GetFloatv, and GetDoublev:
	 */
	public static final int GL_MIN_PROGRAM_TEXTURE_GATHER_OFFSET_ARB = 0x8e5e;
	public static final int GL_MAX_PROGRAM_TEXTURE_GATHER_OFFSET_ARB = 0x8e5f;
	public static final int GL_MAX_PROGRAM_TEXTURE_GATHER_COMPONENTS_ARB = 0x8f9f;
	/**
	 * Accepted by the &lt;target&gt; parameter of BindTransformFeedback: 
	 */
	public static final int GL_TRANSFORM_FEEDBACK = 0x8e22;
	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetDoublev, GetIntegerv,
	 *  and GetFloatv:
	 */
	public static final int GL_TRANSFORM_FEEDBACK_BUFFER_PAUSED = 0x8e23;
	public static final int GL_TRANSFORM_FEEDBACK_BUFFER_ACTIVE = 0x8e24;
	public static final int GL_TRANSFORM_FEEDBACK_BINDING = 0x8e25;
	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetDoublev, GetIntegerv,
	 *  and GetFloatv:
	 */
	public static final int GL_MAX_TRANSFORM_FEEDBACK_BUFFERS = 0x8e70;

	private GL40() {
	}


	public static void glBlendEquationi(int buf, int mode) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glBlendEquationi_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglBlendEquationi(buf, mode, function_pointer);
	}
	private static native void nglBlendEquationi(int buf, int mode, long function_pointer);

	public static void glBlendEquationSeparatei(int buf, int modeRGB, int modeAlpha) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glBlendEquationSeparatei_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglBlendEquationSeparatei(buf, modeRGB, modeAlpha, function_pointer);
	}
	private static native void nglBlendEquationSeparatei(int buf, int modeRGB, int modeAlpha, long function_pointer);

	public static void glBlendFunci(int buf, int src, int dst) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glBlendFunci_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglBlendFunci(buf, src, dst, function_pointer);
	}
	private static native void nglBlendFunci(int buf, int src, int dst, long function_pointer);

	public static void glBlendFuncSeparatei(int buf, int srcRGB, int dstRGB, int srcAlpha, int dstAlpha) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glBlendFuncSeparatei_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglBlendFuncSeparatei(buf, srcRGB, dstRGB, srcAlpha, dstAlpha, function_pointer);
	}
	private static native void nglBlendFuncSeparatei(int buf, int srcRGB, int dstRGB, int srcAlpha, int dstAlpha, long function_pointer);

	public static void glDrawArraysIndirect(int mode, IntBuffer indirect) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glDrawArraysIndirect_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureIndirectBOdisabled(caps);
		BufferChecks.checkBuffer(indirect, 4);
		BufferChecks.checkNullTerminated(indirect);
		nglDrawArraysIndirect(mode, indirect, indirect.position(), function_pointer);
	}
	private static native void nglDrawArraysIndirect(int mode, IntBuffer indirect, int indirect_position, long function_pointer);
	public static void glDrawArraysIndirect(int mode, long indirect_buffer_offset) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glDrawArraysIndirect_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureIndirectBOenabled(caps);
		nglDrawArraysIndirectBO(mode, indirect_buffer_offset, function_pointer);
	}
	private static native void nglDrawArraysIndirectBO(int mode, long indirect_buffer_offset, long function_pointer);

	public static void glDrawElementsIndirect(int mode, int type, IntBuffer indirect) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glDrawElementsIndirect_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureIndirectBOdisabled(caps);
		BufferChecks.checkBuffer(indirect, 5);
		BufferChecks.checkNullTerminated(indirect);
		nglDrawElementsIndirect(mode, type, indirect, indirect.position(), function_pointer);
	}
	private static native void nglDrawElementsIndirect(int mode, int type, IntBuffer indirect, int indirect_position, long function_pointer);
	public static void glDrawElementsIndirect(int mode, int type, long indirect_buffer_offset) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glDrawElementsIndirect_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureIndirectBOenabled(caps);
		nglDrawElementsIndirectBO(mode, type, indirect_buffer_offset, function_pointer);
	}
	private static native void nglDrawElementsIndirectBO(int mode, int type, long indirect_buffer_offset, long function_pointer);

	public static void glUniform1d(int location, double x) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glUniform1d_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglUniform1d(location, x, function_pointer);
	}
	private static native void nglUniform1d(int location, double x, long function_pointer);

	public static void glUniform2d(int location, double x, double y) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glUniform2d_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglUniform2d(location, x, y, function_pointer);
	}
	private static native void nglUniform2d(int location, double x, double y, long function_pointer);

	public static void glUniform3d(int location, double x, double y, double z) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glUniform3d_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglUniform3d(location, x, y, z, function_pointer);
	}
	private static native void nglUniform3d(int location, double x, double y, double z, long function_pointer);

	public static void glUniform4d(int location, double x, double y, double z, double w) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glUniform4d_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglUniform4d(location, x, y, z, w, function_pointer);
	}
	private static native void nglUniform4d(int location, double x, double y, double z, double w, long function_pointer);

	public static void glUniform1(int location, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glUniform1dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniform1dv(location, (value.remaining()), value, value.position(), function_pointer);
	}
	private static native void nglUniform1dv(int location, int count, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniform2(int location, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glUniform2dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniform2dv(location, (value.remaining()) >> 1, value, value.position(), function_pointer);
	}
	private static native void nglUniform2dv(int location, int count, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniform3(int location, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glUniform3dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniform3dv(location, (value.remaining()) / 3, value, value.position(), function_pointer);
	}
	private static native void nglUniform3dv(int location, int count, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniform4(int location, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glUniform4dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniform4dv(location, (value.remaining()) >> 2, value, value.position(), function_pointer);
	}
	private static native void nglUniform4dv(int location, int count, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniformMatrix2(int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glUniformMatrix2dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniformMatrix2dv(location, (value.remaining()) >> 2, transpose, value, value.position(), function_pointer);
	}
	private static native void nglUniformMatrix2dv(int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniformMatrix3(int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glUniformMatrix3dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniformMatrix3dv(location, (value.remaining()) / (3 * 3), transpose, value, value.position(), function_pointer);
	}
	private static native void nglUniformMatrix3dv(int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniformMatrix4(int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glUniformMatrix4dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniformMatrix4dv(location, (value.remaining()) >> 4, transpose, value, value.position(), function_pointer);
	}
	private static native void nglUniformMatrix4dv(int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniformMatrix2x3(int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glUniformMatrix2x3dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniformMatrix2x3dv(location, (value.remaining()) / (2 * 3), transpose, value, value.position(), function_pointer);
	}
	private static native void nglUniformMatrix2x3dv(int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniformMatrix2x4(int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glUniformMatrix2x4dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniformMatrix2x4dv(location, (value.remaining()) >> 3, transpose, value, value.position(), function_pointer);
	}
	private static native void nglUniformMatrix2x4dv(int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniformMatrix3x2(int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glUniformMatrix3x2dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniformMatrix3x2dv(location, (value.remaining()) / (3 * 2), transpose, value, value.position(), function_pointer);
	}
	private static native void nglUniformMatrix3x2dv(int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniformMatrix3x4(int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glUniformMatrix3x4dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniformMatrix3x4dv(location, (value.remaining()) / (3 * 4), transpose, value, value.position(), function_pointer);
	}
	private static native void nglUniformMatrix3x4dv(int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniformMatrix4x2(int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glUniformMatrix4x2dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniformMatrix4x2dv(location, (value.remaining()) >> 3, transpose, value, value.position(), function_pointer);
	}
	private static native void nglUniformMatrix4x2dv(int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glUniformMatrix4x3(int location, boolean transpose, DoubleBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glUniformMatrix4x3dv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniformMatrix4x3dv(location, (value.remaining()) / (4 * 3), transpose, value, value.position(), function_pointer);
	}
	private static native void nglUniformMatrix4x3dv(int location, int count, boolean transpose, DoubleBuffer value, int value_position, long function_pointer);

	public static void glGetUniform(int program, int location, DoubleBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glGetUniformdv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(params);
		nglGetUniformdv(program, location, params, params.position(), function_pointer);
	}
	private static native void nglGetUniformdv(int program, int location, DoubleBuffer params, int params_position, long function_pointer);

	public static void glMinSampleShading(float value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glMinSampleShading_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglMinSampleShading(value, function_pointer);
	}
	private static native void nglMinSampleShading(float value, long function_pointer);

	public static int glGetSubroutineUniformLocation(int program, int shadertype, ByteBuffer name) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glGetSubroutineUniformLocation_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(name);
		BufferChecks.checkNullTerminated(name);
		int __result = nglGetSubroutineUniformLocation(program, shadertype, name, name.position(), function_pointer);
		return __result;
	}
	private static native int nglGetSubroutineUniformLocation(int program, int shadertype, ByteBuffer name, int name_position, long function_pointer);

	public static int glGetSubroutineIndex(int program, int shadertype, ByteBuffer name) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glGetSubroutineIndex_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(name);
		BufferChecks.checkNullTerminated(name);
		int __result = nglGetSubroutineIndex(program, shadertype, name, name.position(), function_pointer);
		return __result;
	}
	private static native int nglGetSubroutineIndex(int program, int shadertype, ByteBuffer name, int name_position, long function_pointer);

	public static void glGetActiveSubroutineUniform(int program, int shadertype, int index, int pname, IntBuffer values) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glGetActiveSubroutineUniformiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(values, 1);
		nglGetActiveSubroutineUniformiv(program, shadertype, index, pname, values, values.position(), function_pointer);
	}
	private static native void nglGetActiveSubroutineUniformiv(int program, int shadertype, int index, int pname, IntBuffer values, int values_position, long function_pointer);

	/** Overloads glGetActiveSubroutineUniformiv */
	public static int glGetActiveSubroutineUniform(int program, int shadertype, int index, int pname) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glGetActiveSubroutineUniformiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer values = APIUtils.getBufferInt();
		nglGetActiveSubroutineUniformiv(program, shadertype, index, pname, values, values.position(), function_pointer);
		return values.get(0);
	}

	public static void glGetActiveSubroutineUniformName(int program, int shadertype, int index, IntBuffer length, ByteBuffer name) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glGetActiveSubroutineUniformName_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		if (length != null)
			BufferChecks.checkBuffer(length, 1);
		BufferChecks.checkDirect(name);
		nglGetActiveSubroutineUniformName(program, shadertype, index, (name.remaining()), length, length != null ? length.position() : 0, name, name.position(), function_pointer);
	}
	private static native void nglGetActiveSubroutineUniformName(int program, int shadertype, int index, int bufsize, IntBuffer length, int length_position, ByteBuffer name, int name_position, long function_pointer);

	/** Overloads glGetActiveSubroutineUniformName */
	public static String glGetActiveSubroutineUniformName(int program, int shadertype, int index, int bufsize) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glGetActiveSubroutineUniformName_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer name_length = APIUtils.getLengths();
		ByteBuffer name = APIUtils.getBufferByte(bufsize);
		nglGetActiveSubroutineUniformName(program, shadertype, index, bufsize, name_length, 0, name, name.position(), function_pointer);
		name.limit(name_length.get(0));
		return APIUtils.getString(name);
	}

	public static void glGetActiveSubroutineName(int program, int shadertype, int index, IntBuffer length, ByteBuffer name) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glGetActiveSubroutineName_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		if (length != null)
			BufferChecks.checkBuffer(length, 1);
		BufferChecks.checkDirect(name);
		nglGetActiveSubroutineName(program, shadertype, index, (name.remaining()), length, length != null ? length.position() : 0, name, name.position(), function_pointer);
	}
	private static native void nglGetActiveSubroutineName(int program, int shadertype, int index, int bufsize, IntBuffer length, int length_position, ByteBuffer name, int name_position, long function_pointer);

	/** Overloads glGetActiveSubroutineName */
	public static String glGetActiveSubroutineName(int program, int shadertype, int index, int bufsize) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glGetActiveSubroutineName_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer name_length = APIUtils.getLengths();
		ByteBuffer name = APIUtils.getBufferByte(bufsize);
		nglGetActiveSubroutineName(program, shadertype, index, bufsize, name_length, 0, name, name.position(), function_pointer);
		name.limit(name_length.get(0));
		return APIUtils.getString(name);
	}

	public static void glUniformSubroutinesu(int shadertype, IntBuffer indices) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glUniformSubroutinesuiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(indices);
		nglUniformSubroutinesuiv(shadertype, (indices.remaining()), indices, indices.position(), function_pointer);
	}
	private static native void nglUniformSubroutinesuiv(int shadertype, int count, IntBuffer indices, int indices_position, long function_pointer);

	public static void glGetUniformSubroutineu(int shadertype, int location, IntBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glGetUniformSubroutineuiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 1);
		nglGetUniformSubroutineuiv(shadertype, location, params, params.position(), function_pointer);
	}
	private static native void nglGetUniformSubroutineuiv(int shadertype, int location, IntBuffer params, int params_position, long function_pointer);

	/** Overloads glGetUniformSubroutineuiv */
	public static int glGetUniformSubroutineu(int shadertype, int location) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glGetUniformSubroutineuiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer params = APIUtils.getBufferInt();
		nglGetUniformSubroutineuiv(shadertype, location, params, params.position(), function_pointer);
		return params.get(0);
	}

	public static void glGetProgramStage(int program, int shadertype, int pname, IntBuffer values) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glGetProgramStageiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(values, 1);
		nglGetProgramStageiv(program, shadertype, pname, values, values.position(), function_pointer);
	}
	private static native void nglGetProgramStageiv(int program, int shadertype, int pname, IntBuffer values, int values_position, long function_pointer);

	/** Overloads glGetProgramStageiv */
	public static int glGetProgramStage(int program, int shadertype, int pname) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glGetProgramStageiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer values = APIUtils.getBufferInt();
		nglGetProgramStageiv(program, shadertype, pname, values, values.position(), function_pointer);
		return values.get(0);
	}

	public static void glPatchParameteri(int pname, int value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glPatchParameteri_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglPatchParameteri(pname, value, function_pointer);
	}
	private static native void nglPatchParameteri(int pname, int value, long function_pointer);

	public static void glPatchParameter(int pname, FloatBuffer values) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glPatchParameterfv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(values, 4);
		nglPatchParameterfv(pname, values, values.position(), function_pointer);
	}
	private static native void nglPatchParameterfv(int pname, FloatBuffer values, int values_position, long function_pointer);

	public static void glBindTransformFeedback(int target, int id) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glBindTransformFeedback_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglBindTransformFeedback(target, id, function_pointer);
	}
	private static native void nglBindTransformFeedback(int target, int id, long function_pointer);

	public static void glDeleteTransformFeedbacks(IntBuffer ids) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glDeleteTransformFeedbacks_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(ids);
		nglDeleteTransformFeedbacks((ids.remaining()), ids, ids.position(), function_pointer);
	}
	private static native void nglDeleteTransformFeedbacks(int n, IntBuffer ids, int ids_position, long function_pointer);

	/** Overloads glDeleteTransformFeedbacks */
	public static void glDeleteTransformFeedbacks(int id) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glDeleteTransformFeedbacks_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglDeleteTransformFeedbacks(1, APIUtils.getBufferInt().put(0, id), 0, function_pointer);
	}

	public static void glGenTransformFeedbacks(IntBuffer ids) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glGenTransformFeedbacks_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(ids);
		nglGenTransformFeedbacks((ids.remaining()), ids, ids.position(), function_pointer);
	}
	private static native void nglGenTransformFeedbacks(int n, IntBuffer ids, int ids_position, long function_pointer);

	/** Overloads glGenTransformFeedbacks */
	public static int glGenTransformFeedbacks() {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glGenTransformFeedbacks_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer ids = APIUtils.getBufferInt();
		nglGenTransformFeedbacks(1, ids, ids.position(), function_pointer);
		return ids.get(0);
	}

	public static boolean glIsTransformFeedback(int id) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glIsTransformFeedback_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		boolean __result = nglIsTransformFeedback(id, function_pointer);
		return __result;
	}
	private static native boolean nglIsTransformFeedback(int id, long function_pointer);

	public static void glPauseTransformFeedback() {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glPauseTransformFeedback_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglPauseTransformFeedback(function_pointer);
	}
	private static native void nglPauseTransformFeedback(long function_pointer);

	public static void glResumeTransformFeedback() {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glResumeTransformFeedback_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglResumeTransformFeedback(function_pointer);
	}
	private static native void nglResumeTransformFeedback(long function_pointer);

	public static void glDrawTransformFeedback(int mode, int id) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glDrawTransformFeedback_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglDrawTransformFeedback(mode, id, function_pointer);
	}
	private static native void nglDrawTransformFeedback(int mode, int id, long function_pointer);

	public static void glDrawTransformFeedbackStream(int mode, int id, int stream) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glDrawTransformFeedbackStream_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglDrawTransformFeedbackStream(mode, id, stream, function_pointer);
	}
	private static native void nglDrawTransformFeedbackStream(int mode, int id, int stream, long function_pointer);

	public static void glBeginQueryIndexed(int target, int index, int id) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glBeginQueryIndexed_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglBeginQueryIndexed(target, index, id, function_pointer);
	}
	private static native void nglBeginQueryIndexed(int target, int index, int id, long function_pointer);

	public static void glEndQueryIndexed(int target, int index) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glEndQueryIndexed_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglEndQueryIndexed(target, index, function_pointer);
	}
	private static native void nglEndQueryIndexed(int target, int index, long function_pointer);

	public static void glGetQueryIndexed(int target, int index, int pname, IntBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glGetQueryIndexediv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 1);
		nglGetQueryIndexediv(target, index, pname, params, params.position(), function_pointer);
	}
	private static native void nglGetQueryIndexediv(int target, int index, int pname, IntBuffer params, int params_position, long function_pointer);

	/** Overloads glGetQueryIndexediv */
	public static int glGetQueryIndexed(int target, int index, int pname) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL40_glGetQueryIndexediv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer params = APIUtils.getBufferInt();
		nglGetQueryIndexediv(target, index, pname, params, params.position(), function_pointer);
		return params.get(0);
	}
}
