/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class GL31 {
	public static final int GL_RED_SNORM = 0x8f90;
	public static final int GL_RG_SNORM = 0x8f91;
	public static final int GL_RGB_SNORM = 0x8f92;
	public static final int GL_RGBA_SNORM = 0x8f93;
	public static final int GL_R8_SNORM = 0x8f94;
	public static final int GL_RG8_SNORM = 0x8f95;
	public static final int GL_RGB8_SNORM = 0x8f96;
	public static final int GL_RGBA8_SNORM = 0x8f97;
	public static final int GL_R16_SNORM = 0x8f98;
	public static final int GL_RG16_SNORM = 0x8f99;
	public static final int GL_RGB16_SNORM = 0x8f9a;
	public static final int GL_RGBA16_SNORM = 0x8f9b;
	public static final int GL_SIGNED_NORMALIZED = 0x8f9c;
	public static final int GL_COPY_READ_BUFFER = 0x8f36;
	public static final int GL_COPY_WRITE_BUFFER = 0x8f37;
	/**
	 * Accepted by the &lt;cap&gt; parameter of IsEnabled, and by
	 * the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv, GetFloatv, and
	 * GetDoublev:
	 */
	public static final int GL_PRIMITIVE_RESTART = 0x8f9d;
	/**
	 * Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv,
	 * GetFloatv, and GetDoublev:
	 */
	public static final int GL_PRIMITIVE_RESTART_INDEX = 0x8f9e;
	/**
	 * Accepted by the &lt;target&gt; parameter of BindBuffer, BufferData,
	 * BufferSubData, MapBuffer, MapBufferRange, BindTexture, UnmapBuffer,
	 * GetBufferSubData, GetBufferParameteriv, GetBufferPointerv, and TexBuffer,
	 * and the <pname> parameter of GetBooleanv, GetDoublev, GetFloatv, and
	 * GetIntegerv:
	 */
	public static final int GL_TEXTURE_BUFFER = 0x8c2a;
	/**
	 * Accepted by the &lt;pname&gt; parameters of GetBooleanv, GetDoublev,
	 * GetFloatv, and GetIntegerv:
	 */
	public static final int GL_MAX_TEXTURE_BUFFER_SIZE = 0x8c2b;
	public static final int GL_TEXTURE_BINDING_BUFFER = 0x8c2c;
	public static final int GL_TEXTURE_BUFFER_DATA_STORE_BINDING = 0x8c2d;
	public static final int GL_TEXTURE_BUFFER_FORMAT = 0x8c2e;
	/**
	 * Accepted by the &lt;cap&gt; parameter of Enable, Disable and IsEnabled;
	 * by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv, GetFloatv
	 * and GetDoublev; and by the &lt;target&gt; parameter of BindTexture,
	 * GetTexParameterfv, GetTexParameteriv, TexParameterf, TexParameteri,
	 * TexParameterfv and TexParameteriv:
	 * Accepted by the &lt;target&gt; parameter of GetTexImage,
	 * GetTexLevelParameteriv, GetTexLevelParameterfv, TexImage2D,
	 * CopyTexImage2D, TexSubImage2D and CopySubTexImage2D:
	 */
	public static final int GL_TEXTURE_RECTANGLE = 0x84f5;
	/**
	 * Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv,
	 * GetFloatv and GetDoublev:
	 */
	public static final int GL_TEXTURE_BINDING_RECTANGLE = 0x84f6;
	/**
	 * Accepted by the &lt;target&gt; parameter of GetTexLevelParameteriv,
	 * GetTexLevelParameterfv, GetTexParameteriv and TexImage2D:
	 */
	public static final int GL_PROXY_TEXTURE_RECTANGLE = 0x84f7;
	/**
	 * Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetDoublev,
	 * GetIntegerv and GetFloatv:
	 */
	public static final int GL_MAX_RECTANGLE_TEXTURE_SIZE = 0x84f8;
	/**
	 * Returned by &lt;type&gt; parameter of GetActiveUniform when the location
	 * &lt;index&gt; for program object &lt;program&gt; is of type sampler2DRect:
	 */
	public static final int GL_SAMPLER_2D_RECT = 0x8b63;
	/**
	 * Returned by &lt;type&gt; parameter of GetActiveUniform when the location
	 * &lt;index&gt; for program object &lt;program&gt; is of type sampler2DRectShadow:
	 */
	public static final int GL_SAMPLER_2D_RECT_SHADOW = 0x8b64;
	/**
	 * Accepted by the &lt;target&gt; parameters of BindBuffer, BufferData,
	 * BufferSubData, MapBuffer, UnmapBuffer, GetBufferSubData, and
	 * GetBufferPointerv:
	 */
	public static final int GL_UNIFORM_BUFFER = 0x8a11;
	/**
	 * Accepted by the &lt;pname&gt; parameter of GetIntegeri_v, GetBooleanv,
	 * GetIntegerv, GetFloatv, and GetDoublev:
	 */
	public static final int GL_UNIFORM_BUFFER_BINDING = 0x8a28;
	/**
	 *Accepted by the &lt;pname&gt; parameter of GetIntegeri_v: 
	 */
	public static final int GL_UNIFORM_BUFFER_START = 0x8a29;
	public static final int GL_UNIFORM_BUFFER_SIZE = 0x8a2a;
	/**
	 * Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv,
	 * GetFloatv, and GetDoublev:
	 */
	public static final int GL_MAX_VERTEX_UNIFORM_BLOCKS = 0x8a2b;
	public static final int GL_MAX_GEOMETRY_UNIFORM_BLOCKS = 0x8a2c;
	public static final int GL_MAX_FRAGMENT_UNIFORM_BLOCKS = 0x8a2d;
	public static final int GL_MAX_COMBINED_UNIFORM_BLOCKS = 0x8a2e;
	public static final int GL_MAX_UNIFORM_BUFFER_BINDINGS = 0x8a2f;
	public static final int GL_MAX_UNIFORM_BLOCK_SIZE = 0x8a30;
	public static final int GL_MAX_COMBINED_VERTEX_UNIFORM_COMPONENTS = 0x8a31;
	public static final int GL_MAX_COMBINED_GEOMETRY_UNIFORM_COMPONENTS = 0x8a32;
	public static final int GL_MAX_COMBINED_FRAGMENT_UNIFORM_COMPONENTS = 0x8a33;
	public static final int GL_UNIFORM_BUFFER_OFFSET_ALIGNMENT = 0x8a34;
	/**
	 *Accepted by the &lt;pname&gt; parameter of GetProgramiv: 
	 */
	public static final int GL_ACTIVE_UNIFORM_BLOCK_MAX_NAME_LENGTH = 0x8a35;
	public static final int GL_ACTIVE_UNIFORM_BLOCKS = 0x8a36;
	/**
	 *Accepted by the &lt;pname&gt; parameter of GetActiveUniformsiv: 
	 */
	public static final int GL_UNIFORM_TYPE = 0x8a37;
	public static final int GL_UNIFORM_SIZE = 0x8a38;
	public static final int GL_UNIFORM_NAME_LENGTH = 0x8a39;
	public static final int GL_UNIFORM_BLOCK_INDEX = 0x8a3a;
	public static final int GL_UNIFORM_OFFSET = 0x8a3b;
	public static final int GL_UNIFORM_ARRAY_STRIDE = 0x8a3c;
	public static final int GL_UNIFORM_MATRIX_STRIDE = 0x8a3d;
	public static final int GL_UNIFORM_IS_ROW_MAJOR = 0x8a3e;
	/**
	 *Accepted by the &lt;pname&gt; parameter of GetActiveUniformBlockiv: 
	 */
	public static final int GL_UNIFORM_BLOCK_BINDING = 0x8a3f;
	public static final int GL_UNIFORM_BLOCK_DATA_SIZE = 0x8a40;
	public static final int GL_UNIFORM_BLOCK_NAME_LENGTH = 0x8a41;
	public static final int GL_UNIFORM_BLOCK_ACTIVE_UNIFORMS = 0x8a42;
	public static final int GL_UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES = 0x8a43;
	public static final int GL_UNIFORM_BLOCK_REFERENCED_BY_VERTEX_SHADER = 0x8a44;
	public static final int GL_UNIFORM_BLOCK_REFERENCED_BY_GEOMETRY_SHADER = 0x8a45;
	public static final int GL_UNIFORM_BLOCK_REFERENCED_BY_FRAGMENT_SHADER = 0x8a46;
	/**
	 *Returned by GetActiveUniformsiv and GetUniformBlockIndex 
	 */
	public static final int GL_INVALID_INDEX = 0xffffffff;

	private GL31() {
	}


	public static void glDrawArraysInstanced(int mode, int first, int count, int primcount) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL31_glDrawArraysInstanced_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglDrawArraysInstanced(mode, first, count, primcount, function_pointer);
	}
	private static native void nglDrawArraysInstanced(int mode, int first, int count, int primcount, long function_pointer);

	public static void glDrawElementsInstanced(int mode, ByteBuffer indices, int primcount) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL31_glDrawElementsInstanced_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureElementVBOdisabled(caps);
		BufferChecks.checkDirect(indices);
		nglDrawElementsInstanced(mode, (indices.remaining()), GL11.GL_UNSIGNED_BYTE, indices, indices.position(), primcount, function_pointer);
	}
	public static void glDrawElementsInstanced(int mode, IntBuffer indices, int primcount) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL31_glDrawElementsInstanced_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureElementVBOdisabled(caps);
		BufferChecks.checkDirect(indices);
		nglDrawElementsInstanced(mode, (indices.remaining()), GL11.GL_UNSIGNED_INT, indices, indices.position() << 2, primcount, function_pointer);
	}
	public static void glDrawElementsInstanced(int mode, ShortBuffer indices, int primcount) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL31_glDrawElementsInstanced_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureElementVBOdisabled(caps);
		BufferChecks.checkDirect(indices);
		nglDrawElementsInstanced(mode, (indices.remaining()), GL11.GL_UNSIGNED_SHORT, indices, indices.position() << 1, primcount, function_pointer);
	}
	private static native void nglDrawElementsInstanced(int mode, int count, int type, Buffer indices, int indices_position, int primcount, long function_pointer);
	public static void glDrawElementsInstanced(int mode, int count, int type, long indices_buffer_offset, int primcount) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL31_glDrawElementsInstanced_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		GLChecks.ensureElementVBOenabled(caps);
		nglDrawElementsInstancedBO(mode, count, type, indices_buffer_offset, primcount, function_pointer);
	}
	private static native void nglDrawElementsInstancedBO(int mode, int count, int type, long indices_buffer_offset, int primcount, long function_pointer);

	public static void glCopyBufferSubData(int readtarget, int writetarget, long readoffset, long writeoffset, long size) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL31_glCopyBufferSubData_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglCopyBufferSubData(readtarget, writetarget, readoffset, writeoffset, size, function_pointer);
	}
	private static native void nglCopyBufferSubData(int readtarget, int writetarget, long readoffset, long writeoffset, long size, long function_pointer);

	public static void glPrimitiveRestartIndex(int index) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL31_glPrimitiveRestartIndex_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglPrimitiveRestartIndex(index, function_pointer);
	}
	private static native void nglPrimitiveRestartIndex(int index, long function_pointer);

	public static void glTexBuffer(int target, int internalformat, int buffer) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL31_glTexBuffer_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglTexBuffer(target, internalformat, buffer, function_pointer);
	}
	private static native void nglTexBuffer(int target, int internalformat, int buffer, long function_pointer);

	public static void glGetUniformIndices(int program, ByteBuffer uniformNames, IntBuffer uniformIndices) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL31_glGetUniformIndices_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(uniformNames);
		BufferChecks.checkNullTerminated(uniformNames, uniformIndices.remaining());
		BufferChecks.checkDirect(uniformIndices);
		nglGetUniformIndices(program, (uniformIndices.remaining()), uniformNames, uniformNames.position(), uniformIndices, uniformIndices.position(), function_pointer);
	}
	private static native void nglGetUniformIndices(int program, int uniformCount, ByteBuffer uniformNames, int uniformNames_position, IntBuffer uniformIndices, int uniformIndices_position, long function_pointer);

	public static void glGetActiveUniforms(int program, IntBuffer uniformIndices, int pname, IntBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL31_glGetActiveUniformsiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(uniformIndices);
		BufferChecks.checkBuffer(params, 1);
		nglGetActiveUniformsiv(program, (uniformIndices.remaining()), uniformIndices, uniformIndices.position(), pname, params, params.position(), function_pointer);
	}
	private static native void nglGetActiveUniformsiv(int program, int uniformCount, IntBuffer uniformIndices, int uniformIndices_position, int pname, IntBuffer params, int params_position, long function_pointer);

	public static void glGetActiveUniformName(int program, int uniformIndex, IntBuffer length, ByteBuffer uniformName) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL31_glGetActiveUniformName_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		if (length != null)
			BufferChecks.checkBuffer(length, 1);
		BufferChecks.checkDirect(uniformName);
		nglGetActiveUniformName(program, uniformIndex, (uniformName.remaining()), length, length != null ? length.position() : 0, uniformName, uniformName.position(), function_pointer);
	}
	private static native void nglGetActiveUniformName(int program, int uniformIndex, int bufSize, IntBuffer length, int length_position, ByteBuffer uniformName, int uniformName_position, long function_pointer);

	public static int glGetUniformBlockIndex(int program, ByteBuffer uniformBlockName) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL31_glGetUniformBlockIndex_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(uniformBlockName);
		BufferChecks.checkNullTerminated(uniformBlockName);
		int __result = nglGetUniformBlockIndex(program, uniformBlockName, uniformBlockName.position(), function_pointer);
		return __result;
	}
	private static native int nglGetUniformBlockIndex(int program, ByteBuffer uniformBlockName, int uniformBlockName_position, long function_pointer);

	public static void glGetActiveUniformBlock(int program, int uniformBlockIndex, int pname, IntBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL31_glGetActiveUniformBlockiv_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 16);
		nglGetActiveUniformBlockiv(program, uniformBlockIndex, pname, params, params.position(), function_pointer);
	}
	private static native void nglGetActiveUniformBlockiv(int program, int uniformBlockIndex, int pname, IntBuffer params, int params_position, long function_pointer);

	public static void glGetActiveUniformBlockName(int program, int uniformBlockIndex, IntBuffer length, ByteBuffer uniformBlockName) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL31_glGetActiveUniformBlockName_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		if (length != null)
			BufferChecks.checkBuffer(length, 1);
		BufferChecks.checkDirect(uniformBlockName);
		nglGetActiveUniformBlockName(program, uniformBlockIndex, (uniformBlockName.remaining()), length, length != null ? length.position() : 0, uniformBlockName, uniformBlockName.position(), function_pointer);
	}
	private static native void nglGetActiveUniformBlockName(int program, int uniformBlockIndex, int bufSize, IntBuffer length, int length_position, ByteBuffer uniformBlockName, int uniformBlockName_position, long function_pointer);

	public static void glUniformBlockBinding(int program, int uniformBlockIndex, int uniformBlockBinding) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.GL31_glUniformBlockBinding_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglUniformBlockBinding(program, uniformBlockIndex, uniformBlockBinding, function_pointer);
	}
	private static native void nglUniformBlockBinding(int program, int uniformBlockIndex, int uniformBlockBinding, long function_pointer);
}
