/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class NVLightMaxExponent {
	public static final int GL_MAX_SHININESS_NV = 0x8504;
	public static final int GL_MAX_SPOT_EXPONENT_NV = 0x8505;

	private NVLightMaxExponent() {
	}

}
