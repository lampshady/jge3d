/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class NVTextureCompressionVTC {
	/**
	 *  Accepted by the &lt;internalformat&gt; parameter of TexImage3D and
	 *  CompressedTexImage3DARB and the &lt;format&gt; parameter of
	 *  CompressedTexSubImage2DARB:
	 */
	public static final int GL_COMPRESSED_RGB_S3TC_DXT1_EXT = 0x83f0;
	public static final int GL_COMPRESSED_RGBA_S3TC_DXT1_EXT = 0x83f1;
	public static final int GL_COMPRESSED_RGBA_S3TC_DXT3_EXT = 0x83f2;
	public static final int GL_COMPRESSED_RGBA_S3TC_DXT5_EXT = 0x83f3;

	private NVTextureCompressionVTC() {
	}

}
