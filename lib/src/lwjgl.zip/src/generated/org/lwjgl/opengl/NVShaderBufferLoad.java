/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class NVShaderBufferLoad {
	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBufferParameterui64vNV,
	 *  GetNamedBufferParameterui64vNV:
	 */
	public static final int GL_BUFFER_GPU_ADDRESS_NV = 0x8f1d;
	/**
	 * Returned by the &lt;type&gt; parameter of GetActiveUniform: 
	 */
	public static final int GL_GPU_ADDRESS_NV = 0x8f34;
	/**
	 * Accepted by the &lt;value&gt; parameter of GetIntegerui64vNV: 
	 */
	public static final int GL_MAX_SHADER_BUFFER_ADDRESS_NV = 0x8f35;

	private NVShaderBufferLoad() {
	}


	public static void glMakeBufferResidentNV(int target, int access) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_shader_buffer_load_glMakeBufferResidentNV_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglMakeBufferResidentNV(target, access, function_pointer);
	}
	private static native void nglMakeBufferResidentNV(int target, int access, long function_pointer);

	public static void glMakeBufferNonResidentNV(int target) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_shader_buffer_load_glMakeBufferNonResidentNV_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglMakeBufferNonResidentNV(target, function_pointer);
	}
	private static native void nglMakeBufferNonResidentNV(int target, long function_pointer);

	public static boolean glIsBufferResidentNV(int target) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_shader_buffer_load_glIsBufferResidentNV_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		boolean __result = nglIsBufferResidentNV(target, function_pointer);
		return __result;
	}
	private static native boolean nglIsBufferResidentNV(int target, long function_pointer);

	public static void glMakeNamedBufferResidentNV(int buffer, int access) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_shader_buffer_load_glMakeNamedBufferResidentNV_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglMakeNamedBufferResidentNV(buffer, access, function_pointer);
	}
	private static native void nglMakeNamedBufferResidentNV(int buffer, int access, long function_pointer);

	public static void glMakeNamedBufferNonResidentNV(int buffer) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_shader_buffer_load_glMakeNamedBufferNonResidentNV_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglMakeNamedBufferNonResidentNV(buffer, function_pointer);
	}
	private static native void nglMakeNamedBufferNonResidentNV(int buffer, long function_pointer);

	public static boolean glIsNamedBufferResidentNV(int buffer) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_shader_buffer_load_glIsNamedBufferResidentNV_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		boolean __result = nglIsNamedBufferResidentNV(buffer, function_pointer);
		return __result;
	}
	private static native boolean nglIsNamedBufferResidentNV(int buffer, long function_pointer);

	public static void glGetBufferParameteruNV(int target, int pname, LongBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_shader_buffer_load_glGetBufferParameterui64vNV_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 1);
		nglGetBufferParameterui64vNV(target, pname, params, params.position(), function_pointer);
	}
	private static native void nglGetBufferParameterui64vNV(int target, int pname, LongBuffer params, int params_position, long function_pointer);

	/** Overloads glGetBufferParameterui64vNV */
	public static long glGetBufferParameteruNV(int target, int pname) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_shader_buffer_load_glGetBufferParameterui64vNV_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		LongBuffer params = APIUtils.getBufferLong();
		nglGetBufferParameterui64vNV(target, pname, params, params.position(), function_pointer);
		return params.get(0);
	}

	public static void glGetNamedBufferParameteruNV(int buffer, int pname, LongBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_shader_buffer_load_glGetNamedBufferParameterui64vNV_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 1);
		nglGetNamedBufferParameterui64vNV(buffer, pname, params, params.position(), function_pointer);
	}
	private static native void nglGetNamedBufferParameterui64vNV(int buffer, int pname, LongBuffer params, int params_position, long function_pointer);

	/** Overloads glGetNamedBufferParameterui64vNV */
	public static long glGetNamedBufferParameteruNV(int buffer, int pname) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_shader_buffer_load_glGetNamedBufferParameterui64vNV_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		LongBuffer params = APIUtils.getBufferLong();
		nglGetNamedBufferParameterui64vNV(buffer, pname, params, params.position(), function_pointer);
		return params.get(0);
	}

	public static void glGetIntegeruNV(int value, LongBuffer result) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_shader_buffer_load_glGetIntegerui64vNV_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(result, 1);
		nglGetIntegerui64vNV(value, result, result.position(), function_pointer);
	}
	private static native void nglGetIntegerui64vNV(int value, LongBuffer result, int result_position, long function_pointer);

	/** Overloads glGetIntegerui64vNV */
	public static long glGetIntegeruNV(int value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_shader_buffer_load_glGetIntegerui64vNV_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		LongBuffer result = APIUtils.getBufferLong();
		nglGetIntegerui64vNV(value, result, result.position(), function_pointer);
		return result.get(0);
	}

	public static void glUniformui64NV(int location, long value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_shader_buffer_load_glUniformui64NV_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglUniformui64NV(location, value, function_pointer);
	}
	private static native void nglUniformui64NV(int location, long value, long function_pointer);

	public static void glUniformuNV(int location, LongBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_shader_buffer_load_glUniformui64vNV_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglUniformui64vNV(location, (value.remaining()), value, value.position(), function_pointer);
	}
	private static native void nglUniformui64vNV(int location, int count, LongBuffer value, int value_position, long function_pointer);

	public static void glGetUniformuNV(int program, int location, LongBuffer params) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_shader_buffer_load_glGetUniformui64vNV_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkBuffer(params, 1);
		nglGetUniformui64vNV(program, location, params, params.position(), function_pointer);
	}
	private static native void nglGetUniformui64vNV(int program, int location, LongBuffer params, int params_position, long function_pointer);

	public static void glProgramUniformui64NV(int program, int location, long value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_shader_buffer_load_glProgramUniformui64NV_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglProgramUniformui64NV(program, location, value, function_pointer);
	}
	private static native void nglProgramUniformui64NV(int program, int location, long value, long function_pointer);

	public static void glProgramUniformuNV(int program, int location, LongBuffer value) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.NV_shader_buffer_load_glProgramUniformui64vNV_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(value);
		nglProgramUniformui64vNV(program, location, (value.remaining()), value, value.position(), function_pointer);
	}
	private static native void nglProgramUniformui64vNV(int program, int location, int count, LongBuffer value, int value_position, long function_pointer);
}
