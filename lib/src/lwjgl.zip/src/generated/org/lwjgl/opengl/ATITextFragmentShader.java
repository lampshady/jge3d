/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class ATITextFragmentShader {
	/**
	 * Accepted by the &lt;cap&gt; parameter of Disable, Enable, and IsEnabled,
	 * and by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv, GetFloatv,
	 * and GetDoublev, and by the &lt;target&gt; parameter of ProgramStringARB,
	 * BindProgramARB, ProgramEnvParameter4{d,dv,f,fv}ARB,
	 * ProgramLocalParameter4{d,dv,f,fv}ARB,
	 * GetProgramEnvParameter{dv,fv}ARB, GetProgramLocalParameter{dv,fv}ARB,
	 * GetProgramivARB, GetProgramfvATI, and GetProgramStringARB.
	 */
	public static final int GL_TEXT_FRAGMENT_SHADER_ATI = 0x8200;

	private ATITextFragmentShader() {
	}

}
