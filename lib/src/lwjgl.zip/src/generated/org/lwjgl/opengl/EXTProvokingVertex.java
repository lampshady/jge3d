/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class EXTProvokingVertex {
	/**
	 *Accepted by the &lt;mode&gt; parameter of ProvokingVertexEXT: 
	 */
	public static final int GL_FIRST_VERTEX_CONVENTION_EXT = 0x8e4d;
	public static final int GL_LAST_VERTEX_CONVENTION_EXT = 0x8e4e;
	/**
	 * Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv,
	 * GetFloatv, and GetDoublev:
	 */
	public static final int GL_PROVOKING_VERTEX_EXT = 0x8e4f;
	public static final int GL_QUADS_FOLLOW_PROVOKING_VERTEX_CONVENTION_EXT = 0x8e4c;

	private EXTProvokingVertex() {
	}


	public static void glProvokingVertexEXT(int mode) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.EXT_provoking_vertex_glProvokingVertexEXT_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglProvokingVertexEXT(mode, function_pointer);
	}
	private static native void nglProvokingVertexEXT(int mode, long function_pointer);
}
