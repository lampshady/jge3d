/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import java.nio.*;

public final class ARBTransformFeedback2 {
	/**
	 * Accepted by the &lt;target&gt; parameter of BindTransformFeedback: 
	 */
	public static final int GL_TRANSFORM_FEEDBACK = 0x8e22;
	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetDoublev, GetIntegerv,
	 *  and GetFloatv:
	 */
	public static final int GL_TRANSFORM_FEEDBACK_BUFFER_PAUSED = 0x8e23;
	public static final int GL_TRANSFORM_FEEDBACK_BUFFER_ACTIVE = 0x8e24;
	public static final int GL_TRANSFORM_FEEDBACK_BINDING = 0x8e25;

	private ARBTransformFeedback2() {
	}


	public static void glBindTransformFeedback(int target, int id) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_transform_feedback2_glBindTransformFeedback_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglBindTransformFeedback(target, id, function_pointer);
	}
	private static native void nglBindTransformFeedback(int target, int id, long function_pointer);

	public static void glDeleteTransformFeedbacks(IntBuffer ids) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_transform_feedback2_glDeleteTransformFeedbacks_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(ids);
		nglDeleteTransformFeedbacks((ids.remaining()), ids, ids.position(), function_pointer);
	}
	private static native void nglDeleteTransformFeedbacks(int n, IntBuffer ids, int ids_position, long function_pointer);

	/** Overloads glDeleteTransformFeedbacks */
	public static void glDeleteTransformFeedbacks(int id) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_transform_feedback2_glDeleteTransformFeedbacks_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglDeleteTransformFeedbacks(1, APIUtils.getBufferInt().put(0, id), 0, function_pointer);
	}

	public static void glGenTransformFeedbacks(IntBuffer ids) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_transform_feedback2_glGenTransformFeedbacks_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		BufferChecks.checkDirect(ids);
		nglGenTransformFeedbacks((ids.remaining()), ids, ids.position(), function_pointer);
	}
	private static native void nglGenTransformFeedbacks(int n, IntBuffer ids, int ids_position, long function_pointer);

	/** Overloads glGenTransformFeedbacks */
	public static int glGenTransformFeedbacks() {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_transform_feedback2_glGenTransformFeedbacks_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		IntBuffer ids = APIUtils.getBufferInt();
		nglGenTransformFeedbacks(1, ids, ids.position(), function_pointer);
		return ids.get(0);
	}

	public static boolean glIsTransformFeedback(int id) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_transform_feedback2_glIsTransformFeedback_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		boolean __result = nglIsTransformFeedback(id, function_pointer);
		return __result;
	}
	private static native boolean nglIsTransformFeedback(int id, long function_pointer);

	public static void glPauseTransformFeedback() {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_transform_feedback2_glPauseTransformFeedback_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglPauseTransformFeedback(function_pointer);
	}
	private static native void nglPauseTransformFeedback(long function_pointer);

	public static void glResumeTransformFeedback() {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_transform_feedback2_glResumeTransformFeedback_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglResumeTransformFeedback(function_pointer);
	}
	private static native void nglResumeTransformFeedback(long function_pointer);

	public static void glDrawTransformFeedback(int mode, int id) {
		ContextCapabilities caps = GLContext.getCapabilities();
		long function_pointer = caps.ARB_transform_feedback2_glDrawTransformFeedback_pointer;
		BufferChecks.checkFunctionAddress(function_pointer);
		nglDrawTransformFeedback(mode, id, function_pointer);
	}
	private static native void nglDrawTransformFeedback(int mode, int id, long function_pointer);
}
